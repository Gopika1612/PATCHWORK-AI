# Hyperlocal Reserve — Electronics 🔋

> **Find it nearby. Compare it smartly. Inspect before you buy.**

A fully interactive, zero-cost local demo application that helps customers discover nearby electronics retailers, compare product prices with a TrueCost™ breakdown, and reserve products for in-store inspection.

---

## ⚡ DEMO MODE NOTICE

> All stores, products, prices, stock information, phone numbers, email addresses, and reservation data in this application are **fictional and illustrative**. No real transactions, purchases, or reservations are processed.

---

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ and npm 9+

### Install & Run

```bash
# Navigate to the project folder
cd hyperlocal-reserve-electronics

# Install dependencies
npm install

# Start development server
npm run dev
```

Open **http://localhost:5173** in your browser.

### Production Build

```bash
npm run build
npm run preview   # preview the production build locally
```

---

## 🗂 Project Structure

```
hyperlocal-reserve-electronics/
├── src/
│   ├── components/
│   │   ├── Layout.tsx        # Navbar, Footer, demo account switcher
│   │   └── Shared.tsx        # ProductCard, StoreCard, TrueCostWidget, Toast, etc.
│   ├── pages/
│   │   ├── HomePage.tsx      # Hero, categories, featured products
│   │   ├── ProductsPage.tsx  # Search, filter, sort products
│   │   ├── ProductDetailPage.tsx  # Product info + TrueCost + price comparison
│   │   ├── ComparisonPage.tsx    # Full store-by-store price table
│   │   ├── StoresPage.tsx        # Store browser
│   │   ├── StoreDetailPage.tsx   # Store profile + products
│   │   ├── ReservationPage.tsx   # 3-step reservation form
│   │   ├── MyReservationsPage.tsx # Reservation history + cancellation
│   │   ├── RetailerDashboard.tsx  # Inventory CRUD + reservation management
│   │   └── AdminPage.tsx         # Demo data admin + safe reset
│   ├── data/
│   │   └── seedData.ts       # 8 products, 5 stores, 20 listings, 3 sample reservations
│   ├── services/
│   │   └── dataService.ts    # localStorage CRUD abstraction
│   ├── types/
│   │   └── index.ts          # All TypeScript types
│   ├── utils/
│   │   ├── helpers.ts        # Currency, distance, date formatters
│   │   └── trueCost.ts       # TrueCost™ calculation engine + EMI calculator
│   └── tests/
│       └── trueCost.test.ts  # Unit tests for TrueCost engine
├── public/
│   └── icon.svg              # Custom SVG favicon
├── index.html
├── vite.config.ts
├── README.md
└── DEMO_GUIDE.md
```

---

## 🧪 Running Unit Tests

The TrueCost calculation engine has a standalone test suite:

```bash
# Install tsx (TypeScript executor) if needed
npm install -D tsx

# Run tests
npx tsx src/tests/trueCost.test.ts
```

Tests cover:
- Basic price + mandatory fee calculation
- Delivery charge inclusion/exclusion
- Eligible discount application
- Double-discount prevention
- Unknown delivery charge handling (`null` → "Not provided")
- Input validation (negative price throws)
- Total cannot go below zero
- EMI calculator (with and without interest, edge cases)

---

## 🔑 Features

| Feature | Status |
|---------|--------|
| Product search (name, brand, model) | ✅ |
| Category + brand + price + stock filters | ✅ |
| Sort by price / distance / relevance | ✅ |
| Geolocation (optional, browser permission) | ✅ |
| Product detail with specs | ✅ |
| Price comparison across stores | ✅ |
| TrueCost™ calculator (fees, discounts, delivery) | ✅ |
| EMI calculator (separate, non-mixed) | ✅ |
| 3-step reservation form with validation | ✅ |
| Reservation reference number generation | ✅ |
| My Reservations with status filters | ✅ |
| Reservation cancellation with confirmation | ✅ |
| LocalStorage persistence across refreshes | ✅ |
| Retailer inventory CRUD | ✅ |
| Retailer reservation accept/reject/complete | ✅ |
| Admin data overview + safe reset | ✅ |
| Demo account switcher (customer/retailer/admin) | ✅ |
| Responsive layout (desktop/tablet/mobile) | ✅ |
| External map links (Google Maps) | ✅ |
| Dark mode theme (ash-grey + emerald-green) | ✅ |

---

## 🗺 Pages

| Path | Page |
|------|------|
| `/` | Home |
| `/products` | Product Discovery |
| `/products/:id` | Product Detail + TrueCost |
| `/compare/:productId` | Price Comparison Table |
| `/stores` | Store Browser |
| `/stores/:id` | Store Detail |
| `/reserve/:listingId` | Reservation Form |
| `/reservations` | My Reservations |
| `/retailer` | Retailer Dashboard (switch to retailer account) |
| `/admin` | Admin Panel (switch to admin account) |

---

## 💾 Data Persistence

- All data is stored in **browser localStorage**.
- Demo data is seeded on first load.
- Reservations persist across page refreshes in the same browser.
- Data is device-specific — not shared across browsers or devices.
- LocalStorage is not suitable for sensitive personal information or multi-user production use.

---

## 📐 TrueCost™ Formula

```
Estimated Total = Listed Price
                + Applicable Mandatory Fees (e.g. GST)
                + Optional Delivery Charge (if selected)
                − Eligible Discounts (when eligibility confirmed)
```

**Rules:**
- Prices and fees must be non-negative.
- Each discount is applied at most once.
- Unknown delivery is shown as "Not provided" — never silently treated as zero.
- EMI is a separate financing tool and does not mix with the outright price.

---

## ⚠ Limitations

1. **Not production-ready**: localStorage has no access control, encryption, or concurrency guarantees.
2. **No real payment**: This demo intentionally does not collect payment information.
3. **No real retailers**: All store and product data is fictional.
4. **No backend**: A real deployment needs a server, database, and authentication.
5. **No stock locking**: Multiple users could "reserve" the same unit simultaneously in this demo.
6. **Geolocation**: Distance sorting requires user permission. Falls back to name/city sorting.
7. **Images**: Product images are sourced from Unsplash (requires internet). Fallback placeholder shown on load failure.

---

## 🔒 Security Notes

- No payment credentials are collected or stored.
- No API keys are required or embedded.
- Do not enter real personal information into the demo — localStorage is browser-readable.
- The demo account switcher is not secure authentication.

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 18 + TypeScript |
| Build tool | Vite |
| Styling | Tailwind CSS v4 + vanilla CSS variables |
| Icons | Lucide React |
| Routing | React Router DOM v6 |
| Storage | Browser localStorage |
| Tests | Custom test harness (tsx) |

---

## 📄 License

This is a demo/educational project. All fictional data is illustrative only.
