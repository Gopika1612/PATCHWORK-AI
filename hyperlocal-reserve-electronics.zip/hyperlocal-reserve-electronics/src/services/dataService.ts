// ─────────────────────────────────────────────────────────────────
// Data Service — abstraction layer over localStorage
// Provides CRUD for products, stores, listings, and reservations.
// Seeded once on first run; resetable by admin.
// ─────────────────────────────────────────────────────────────────

import type {
  Product,
  Store,
  StoreListing,
  Reservation,
  SearchFilters,
  UserLocation,
  StockStatus,
} from '../types';
import {
  PRODUCTS,
  STORES,
  STORE_LISTINGS,
  SAMPLE_RESERVATIONS,
} from '../data/seedData';
import { haversineDistance, generateId, generateReferenceNumber } from '../utils/helpers';

const KEYS = {
  products: 'hlr_products',
  stores: 'hlr_stores',
  listings: 'hlr_listings',
  reservations: 'hlr_reservations',
  seeded: 'hlr_seeded',
};

// ── Storage helpers ───────────────────────────────────────────────
function load<T>(key: string): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    return JSON.parse(raw) as T[];
  } catch {
    return [];
  }
}

function save<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// ── Seeding ───────────────────────────────────────────────────────
export function ensureSeeded(): void {
  if (localStorage.getItem(KEYS.seeded)) return;
  save(KEYS.products, PRODUCTS);
  save(KEYS.stores, STORES);
  save(KEYS.listings, STORE_LISTINGS);
  save(KEYS.reservations, SAMPLE_RESERVATIONS);
  localStorage.setItem(KEYS.seeded, '1');
}

export function resetDemoData(): void {
  save(KEYS.products, PRODUCTS);
  save(KEYS.stores, STORES);
  save(KEYS.listings, STORE_LISTINGS);
  save(KEYS.reservations, SAMPLE_RESERVATIONS);
  localStorage.setItem(KEYS.seeded, '1');
}

// ── Products ──────────────────────────────────────────────────────
export function getProducts(): Product[] {
  return load<Product>(KEYS.products);
}

export function getProductById(id: string): Product | undefined {
  return getProducts().find(p => p.id === id);
}

export function searchProducts(filters: SearchFilters, userLocation?: UserLocation | null): (Product & { minPrice: number; storeCount: number; distanceKm?: number })[] {
  const products = getProducts();
  const listings = getListings();
  const stores = getStores();

  const q = filters.query.toLowerCase().trim();

  const enriched = products
    .map(product => {
      let productListings = listings.filter(l => l.productId === product.id && l.isAvailable);

      if (filters.stockStatus) {
        productListings = productListings.filter(l => l.stockStatus === filters.stockStatus);
      }
      if (filters.minPrice !== '') {
        productListings = productListings.filter(l => l.price >= Number(filters.minPrice));
      }
      if (filters.maxPrice !== '') {
        productListings = productListings.filter(l => l.price <= Number(filters.maxPrice));
      }
      if (productListings.length === 0) return null;

      const minPrice = Math.min(...productListings.map(l => l.price));
      const storeCount = new Set(productListings.map(l => l.storeId)).size;

      let relevanceScore = 0;
      if (q) {
        if (product.name.toLowerCase().includes(q)) relevanceScore += 3;
        if (product.brand.toLowerCase().includes(q)) relevanceScore += 2;
        if (product.model.toLowerCase().includes(q)) relevanceScore += 2;
        if (product.tags.join(' ').toLowerCase().includes(q)) relevanceScore += 1;
        if (product.shortDescription.toLowerCase().includes(q)) relevanceScore += 1;
        if (relevanceScore === 0) return null;
      }

      if (filters.category && product.category !== filters.category) return null;
      if (filters.brand && product.brand.toLowerCase() !== filters.brand.toLowerCase()) return null;

      let distanceKm: number | undefined;
      if (userLocation?.granted) {
        const productStores = stores.filter(s => productListings.some(l => l.storeId === s.id));
        if (productStores.length > 0) {
          const dists = productStores.map(s =>
            haversineDistance(userLocation.lat, userLocation.lng, s.coordinates.lat, s.coordinates.lng)
          );
          distanceKm = Math.min(...dists);
        }
      }

      return { ...product, minPrice, storeCount, distanceKm, relevanceScore };
    })
    .filter(Boolean) as (Product & { minPrice: number; storeCount: number; distanceKm?: number; relevanceScore?: number })[];

  return enriched.sort((a, b) => {
    switch (filters.sortBy) {
      case 'price_asc': return a.minPrice - b.minPrice;
      case 'price_desc': return b.minPrice - a.minPrice;
      case 'distance':
        if (a.distanceKm !== undefined && b.distanceKm !== undefined) return a.distanceKm - b.distanceKm;
        return 0;
      case 'relevance':
      default:
        return ((b as any).relevanceScore ?? 0) - ((a as any).relevanceScore ?? 0);
    }
  });
}

// ── Stores ────────────────────────────────────────────────────────
export function getStores(): Store[] {
  return load<Store>(KEYS.stores);
}

export function getStoreById(id: string): Store | undefined {
  return getStores().find(s => s.id === id);
}

// ── Listings ──────────────────────────────────────────────────────
export function getListings(): StoreListing[] {
  return load<StoreListing>(KEYS.listings);
}

export function getListingById(id: string): StoreListing | undefined {
  return getListings().find(l => l.id === id);
}

export function getListingsForProduct(productId: string): StoreListing[] {
  return getListings().filter(l => l.productId === productId);
}

export function getListingsForStore(storeId: string): StoreListing[] {
  return getListings().filter(l => l.storeId === storeId);
}

export function updateListing(updated: StoreListing): void {
  const listings = getListings();
  const idx = listings.findIndex(l => l.id === updated.id);
  if (idx === -1) throw new Error(`Listing ${updated.id} not found`);
  listings[idx] = { ...updated, lastUpdated: new Date().toISOString() };
  save(KEYS.listings, listings);
}

export function createListing(listing: Omit<StoreListing, 'id' | 'lastUpdated'>): StoreListing {
  const listings = getListings();
  const newListing: StoreListing = {
    ...listing,
    id: generateId('lst'),
    lastUpdated: new Date().toISOString(),
  };
  listings.push(newListing);
  save(KEYS.listings, listings);
  return newListing;
}

export function deleteListing(id: string): void {
  const listings = getListings().filter(l => l.id !== id);
  save(KEYS.listings, listings);
}

// ── Reservations ──────────────────────────────────────────────────
export function getReservations(): Reservation[] {
  return load<Reservation>(KEYS.reservations);
}

export function getReservationById(id: string): Reservation | undefined {
  return getReservations().find(r => r.id === id);
}

export function getReservationsForStore(storeId: string): Reservation[] {
  return getReservations().filter(r => r.storeId === storeId);
}

export function createReservation(
  data: Omit<Reservation, 'id' | 'referenceNumber' | 'createdAt' | 'updatedAt' | 'status'>
): Reservation {
  const reservations = getReservations();
  const now = new Date().toISOString();
  const newRes: Reservation = {
    ...data,
    id: generateId('res'),
    referenceNumber: generateReferenceNumber(),
    status: 'pending',
    createdAt: now,
    updatedAt: now,
  };
  reservations.push(newRes);
  save(KEYS.reservations, reservations);
  return newRes;
}

export function updateReservationStatus(
  id: string,
  status: Reservation['status'],
  notes?: string
): Reservation {
  const reservations = getReservations();
  const idx = reservations.findIndex(r => r.id === id);
  if (idx === -1) throw new Error(`Reservation ${id} not found`);
  reservations[idx] = {
    ...reservations[idx],
    status,
    updatedAt: new Date().toISOString(),
    notes: notes ?? reservations[idx].notes,
  };
  save(KEYS.reservations, reservations);
  return reservations[idx];
}
