import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Info } from 'lucide-react';
import { getProductById, getListingsForProduct, getStoreById } from '../services/dataService';
import { ListingRow } from '../components/Shared';
import type { Product, StoreListing, Store } from '../types';
import { formatINR } from '../utils/helpers';

export default function ComparisonPage() {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [listings, setListings] = useState<(StoreListing & { store: Store })[]>([]);

  useEffect(() => {
    if (!productId) return;
    const p = getProductById(productId);
    if (!p) return;
    setProduct(p);

    const ls = getListingsForProduct(productId)
      .map(l => {
        const store = getStoreById(l.storeId);
        return store ? { ...l, store } : null;
      })
      .filter(Boolean) as (StoreListing & { store: Store })[];

    ls.sort((a, b) => a.price - b.price);
    setListings(ls);
  }, [productId]);

  if (!product) {
    return (
      <div className="page-wrapper"><div className="container">
        <div className="empty-state"><h3>Product not found</h3><Link to="/products" className="btn btn-primary">Browse Products</Link></div>
      </div></div>
    );
  }

  const availableListings = listings.filter(l => l.isAvailable);
  const cheapestPrice = availableListings.length > 0 ? Math.min(...availableListings.map(l => l.price)) : null;
  const cannotDetermineCheapest = availableListings.some(l => l.mandatoryFees.length === 0);

  return (
    <div className="page-wrapper">
      <div className="container">
        <Link to={`/products/${productId}`} style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '0.875rem' }}>
          <ArrowLeft size={14} /> Back to Product
        </Link>

        <div style={{ marginBottom: '2rem' }}>
          <h1 style={{ margin: '0 0 0.25rem', fontSize: '1.75rem' }}>Price Comparison</h1>
          <p style={{ color: 'var(--text-secondary)', margin: 0 }}>{product.name} — {listings.length} store listing{listings.length !== 1 ? 's' : ''} · DEMO DATA</p>
        </div>

        {/* Notice about cheapest */}
        {cannotDetermineCheapest && (
          <div style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 'var(--radius)', padding: '0.875rem 1.25rem', marginBottom: '1.5rem', display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
            <Info size={16} style={{ color: '#fcd34d', flexShrink: 0, marginTop: 2 }} />
            <div style={{ fontSize: '0.85rem', color: '#fcd34d' }}>
              <strong>Note:</strong> Some stores haven't listed all mandatory fees. We cannot confidently identify the cheapest option without complete fee information. Review each row carefully.
            </div>
          </div>
        )}

        {/* Summary stats */}
        {availableListings.length > 0 && (
          <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
            <div className="stat-card"><div className="stat-value">{listings.length}</div><div className="stat-label">Total Listings</div></div>
            <div className="stat-card"><div className="stat-value">{availableListings.length}</div><div className="stat-label">Available</div></div>
            <div className="stat-card"><div className="stat-value">{cheapestPrice ? formatINR(cheapestPrice) : '—'}</div><div className="stat-label">Lowest Listed Price</div></div>
            <div className="stat-card">
              <div className="stat-value">
                {availableListings.length >= 2
                  ? formatINR(Math.max(...availableListings.map(l => l.price)) - Math.min(...availableListings.map(l => l.price)))
                  : '—'}
              </div>
              <div className="stat-label">Price Spread</div>
            </div>
          </div>
        )}

        {/* Comparison table */}
        {listings.length === 0 ? (
          <div className="empty-state"><h3>No listings found</h3><p>No demo stores carry this product.</p></div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Store</th>
                  <th>Listed Price</th>
                  <th>Mandatory Fees</th>
                  <th>Discounts</th>
                  <th>Delivery</th>
                  <th>Est. Min. Total</th>
                  <th>Stock</th>
                  <th>Distance</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {listings.map(l => (
                  <ListingRow
                    key={l.id}
                    listing={l}
                    store={l.store}
                    isCheapest={!cannotDetermineCheapest && l.price === cheapestPrice && l.isAvailable}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}

        <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '1rem', textAlign: 'center' }}>
          ⚠ DEMO DATA — All prices, fees, and stock are fictional and illustrative. Discounts are conditional; check eligibility before visiting.
        </p>
      </div>
    </div>
  );
}
