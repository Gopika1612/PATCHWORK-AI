import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search, MapPin, Zap, Shield, Clock, TrendingUp,
  Laptop, Smartphone, Monitor, Package, Headphones,
  ChevronRight, ArrowRight, Star, Gamepad2
} from 'lucide-react';
import { getProducts, getStores, getListings, ensureSeeded } from '../services/dataService';
import { ProductCard, StoreCard } from '../components/Shared';
import type { Product, Store, StoreListing, Category } from '../types';

const CATEGORIES: { id: Category; label: string; icon: React.ReactNode; color: string }[] = [
  { id: 'laptops', label: 'Laptops', icon: <Laptop size={22} />, color: '#10b981' },
  { id: 'smartphones', label: 'Smartphones', icon: <Smartphone size={22} />, color: '#6366f1' },
  { id: 'monitors', label: 'Monitors', icon: <Monitor size={22} />, color: '#f59e0b' },
  { id: 'tablets', label: 'Tablets', icon: <Package size={22} />, color: '#8b5cf6' },
  { id: 'accessories', label: 'Accessories', icon: <Headphones size={22} />, color: '#ef4444' },
  { id: 'gaming', label: 'Gaming', icon: <Gamepad2 size={22} />, color: '#ec4899' },
];

const HOW_IT_WORKS = [
  { step: '01', title: 'Search Products', desc: 'Find the exact electronics you want by name, brand, or model number.', icon: <Search size={24} /> },
  { step: '02', title: 'Compare Prices', desc: 'See all nearby stores with pricing, fees, and real-time stock status.', icon: <TrendingUp size={24} /> },
  { step: '03', title: 'Calculate True Cost', desc: 'Know the exact total including taxes, discounts, and delivery before you visit.', icon: <Shield size={24} /> },
  { step: '04', title: 'Reserve & Inspect', desc: 'Book a slot to inspect the product in store — no payment required.', icon: <Clock size={24} /> },
];

export default function HomePage() {
  const [query, setQuery] = useState('');
  const [products, setProducts] = useState<(Product & { minPrice: number; storeCount: number })[]>([]);
  const [stores, setStores] = useState<(Store & { listingCount: number })[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    ensureSeeded();
    const allProducts = getProducts();
    const allListings = getListings();
    const allStores = getStores();

    const enriched = allProducts.slice(0, 6).map(p => {
      const ls = allListings.filter(l => l.productId === p.id && l.isAvailable);
      const minPrice = ls.length > 0 ? Math.min(...ls.map(l => l.price)) : 0;
      const storeCount = new Set(ls.map(l => l.storeId)).size;
      return { ...p, minPrice, storeCount };
    });

    const enrichedStores = allStores.map(s => ({
      ...s,
      listingCount: allListings.filter(l => l.storeId === s.id && l.isAvailable).length,
    }));

    setProducts(enriched);
    setStores(enrichedStores);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) navigate(`/products?q=${encodeURIComponent(query.trim())}`);
    else navigate('/products');
  };

  return (
    <div>
      {/* ── Hero ───────────────────────────────────────────────── */}
      <section className="hero-gradient" style={{ padding: '5rem 0 4rem', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        {/* Background decoration */}
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 80% 50%, rgba(99,102,241,0.08) 0%, transparent 60%)', pointerEvents: 'none' }} />

        <div className="container">
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.3)', borderRadius: 999, padding: '0.3rem 0.875rem', marginBottom: '1.5rem' }}>
            <span style={{ color: '#fcd34d', fontSize: '0.8rem', fontWeight: 600 }}>⚡ DEMO MODE — All data is fictional</span>
          </div>

          <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 900, margin: '0 0 1rem', lineHeight: 1.1 }}>
            Find it nearby.<br />
            <span style={{ background: 'linear-gradient(135deg, var(--emerald), var(--emerald-light))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Compare it smartly.
            </span><br />
            Inspect before you buy.
          </h1>

          <p style={{ fontSize: '1.1rem', color: 'var(--text-secondary)', maxWidth: 560, margin: '0 auto 2.5rem', lineHeight: 1.7 }}>
            Discover which nearby electronics retailers have your product in stock — with real pricing, fees, and a TrueCost™ breakdown before you walk in.
          </p>

          {/* Search bar */}
          <form onSubmit={handleSearch} style={{ maxWidth: 580, margin: '0 auto', display: 'flex', gap: '0.5rem', position: 'relative' }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <Search size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                className="form-input"
                type="text"
                placeholder="Search laptops, phones, monitors…"
                value={query}
                onChange={e => setQuery(e.target.value)}
                style={{ paddingLeft: '2.75rem', height: 52, fontSize: '1rem', borderRadius: 12 }}
                aria-label="Product search"
                id="hero-search"
              />
            </div>
            <button type="submit" className="btn btn-primary btn-lg" style={{ borderRadius: 12, gap: '0.4rem' }}>
              Search <ArrowRight size={18} />
            </button>
          </form>

          {/* Quick stats */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: '2.5rem', marginTop: '3rem', flexWrap: 'wrap' }}>
            {[['8+', 'Products'], ['5', 'Demo Stores'], ['20+', 'Listings'], ['100%', 'Free Demo']].map(([val, label]) => (
              <div key={label} style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--emerald)' }}>{val}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Category shortcuts ────────────────────────────────── */}
      <section style={{ padding: '3rem 0', background: 'var(--bg-card)' }}>
        <div className="container">
          <div className="section-header" style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
            <h2 className="section-title" style={{ fontSize: '1.5rem' }}>Browse by Category</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '1rem' }}>
            {CATEGORIES.map(cat => (
              <Link
                key={cat.id}
                to={`/products?category=${cat.id}`}
                style={{ textDecoration: 'none' }}
              >
                <div
                  className="card"
                  style={{
                    padding: '1.25rem', textAlign: 'center', cursor: 'pointer',
                    border: `1px solid ${cat.color}22`,
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLDivElement).style.background = `${cat.color}11`;
                    (e.currentTarget as HTMLDivElement).style.borderColor = `${cat.color}66`;
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLDivElement).style.background = '';
                    (e.currentTarget as HTMLDivElement).style.borderColor = `${cat.color}22`;
                  }}
                >
                  <div style={{ color: cat.color, marginBottom: '0.6rem', display: 'flex', justifyContent: 'center' }}>
                    {cat.icon}
                  </div>
                  <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>{cat.label}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── Featured products ─────────────────────────────────── */}
      <section style={{ padding: '3.5rem 0' }}>
        <div className="container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <div>
              <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Featured Electronics</h2>
              <p style={{ margin: '0.25rem 0 0', color: 'var(--text-secondary)', fontSize: '0.875rem' }}>DEMO DATA — prices are fictional</p>
            </div>
            <Link to="/products" className="btn btn-secondary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              View all <ChevronRight size={16} />
            </Link>
          </div>
          <div className="grid-3">
            {products.map(p => (
              <ProductCard key={p.id} product={p} minPrice={p.minPrice} storeCount={p.storeCount} />
            ))}
          </div>
        </div>
      </section>

      {/* ── How it works ──────────────────────────────────────── */}
      <section style={{ padding: '3.5rem 0', background: 'var(--bg-card)' }}>
        <div className="container">
          <div className="section-header" style={{ textAlign: 'center' }}>
            <h2 className="section-title">How It Works</h2>
            <p className="section-subtitle">From discovery to inspection in 4 simple steps</p>
          </div>
          <div className="grid-4">
            {HOW_IT_WORKS.map((step, i) => (
              <div key={i} className="card fade-in-up" style={{ padding: '1.5rem', animationDelay: `${i * 0.1}s` }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: 'rgba(16,185,129,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--emerald)' }}>
                    {step.icon}
                  </div>
                  <span style={{ fontSize: '0.7rem', fontWeight: 800, color: 'var(--text-muted)', letterSpacing: '0.1em' }}>STEP {step.step}</span>
                </div>
                <h3 style={{ margin: '0 0 0.5rem', fontSize: '1rem' }}>{step.title}</h3>
                <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Nearby Demo Stores ────────────────────────────────── */}
      <section style={{ padding: '3.5rem 0' }}>
        <div className="container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <div>
              <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Demo Stores</h2>
              <p style={{ margin: '0.25rem 0 0', color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Fictional retailer profiles for demonstration</p>
            </div>
            <Link to="/stores" className="btn btn-secondary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              View all <ChevronRight size={16} />
            </Link>
          </div>
          <div className="grid-3">
            {stores.slice(0, 3).map(s => (
              <StoreCard key={s.id} store={s} listingCount={s.listingCount} />
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA Banner ────────────────────────────────────────── */}
      <section style={{ padding: '3.5rem 0', background: 'linear-gradient(135deg, rgba(16,185,129,0.1), rgba(99,102,241,0.1))', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
        <div className="container" style={{ textAlign: 'center' }}>
          <Zap size={40} color="var(--emerald)" style={{ marginBottom: '1rem' }} />
          <h2 style={{ fontSize: '2rem', margin: '0 0 0.75rem' }}>Ready to find your next gadget?</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '1.5rem', fontSize: '1rem' }}>
            Browse the demo product catalogue and explore the TrueCost™ calculator.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link to="/products" className="btn btn-primary btn-lg">Browse Products</Link>
            <Link to="/stores" className="btn btn-secondary btn-lg">Find Stores</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
