import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft, MapPin, Package, ExternalLink, TrendingUp,
  AlertCircle, CheckCircle, Clock, ChevronDown, ChevronUp
} from 'lucide-react';
import { getProductById, getListingsForProduct, getStoreById } from '../services/dataService';
import { TrueCostWidget, ListingRow } from '../components/Shared';
import type { Product, StoreListing, Store } from '../types';
import { stockLabel, stockColor, formatINR, formatDateTime, mapsLink } from '../utils/helpers';

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [listings, setListings] = useState<(StoreListing & { store: Store })[]>([]);
  const [selectedListingId, setSelectedListingId] = useState<string | null>(null);
  const [imgError, setImgError] = useState(false);
  const [specsOpen, setSpecsOpen] = useState(true);

  useEffect(() => {
    if (!id) return;
    const p = getProductById(id);
    if (!p) return;
    setProduct(p);

    const ls = getListingsForProduct(id).map(l => {
      const store = getStoreById(l.storeId);
      return store ? { ...l, store } : null;
    }).filter(Boolean) as (StoreListing & { store: Store })[];

    ls.sort((a, b) => a.price - b.price);
    setListings(ls);
    if (ls.length > 0) setSelectedListingId(ls[0].id);
  }, [id]);

  if (!product) {
    return (
      <div className="page-wrapper">
        <div className="container">
          <div className="empty-state">
            <div className="empty-state-icon">📦</div>
            <h3>Product not found</h3>
            <p>This product doesn't exist in the demo dataset.</p>
            <Link to="/products" className="btn btn-primary" style={{ marginTop: '1rem' }}>Browse Products</Link>
          </div>
        </div>
      </div>
    );
  }

  const selectedListing = listings.find(l => l.id === selectedListingId);
  const cheapestPrice = listings.filter(l => l.isAvailable).length > 0
    ? Math.min(...listings.filter(l => l.isAvailable).map(l => l.price))
    : null;

  return (
    <div className="page-wrapper">
      <div className="container">
        {/* Breadcrumb */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.5rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
          <Link to="/products" style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: 'var(--text-muted)' }}>
            <ArrowLeft size={14} /> Products
          </Link>
          <span>/</span>
          <span style={{ textTransform: 'capitalize' }}>{product.category}</span>
          <span>/</span>
          <span style={{ color: 'var(--text-primary)' }}>{product.name}</span>
        </div>

        {/* Main layout */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '2rem', alignItems: 'start' }}>
          {/* Left: product info */}
          <div>
            {/* Image */}
            <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', background: 'var(--bg-elevated)', marginBottom: '1.5rem', aspectRatio: '16/9', maxHeight: 380, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {!imgError ? (
                <img src={product.imageUrl} alt={product.name} onError={() => setImgError(true)} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem', color: 'var(--text-muted)' }}>
                  <Package size={48} style={{ opacity: 0.4 }} />
                  <span>{product.brand}</span>
                </div>
              )}
            </div>

            {/* Product info */}
            <div style={{ marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem', flexWrap: 'wrap' }}>
                <span className="badge badge-emerald" style={{ textTransform: 'capitalize' }}>{product.category}</span>
                <span className="badge badge-gray">{product.brand}</span>
              </div>
              <h1 style={{ fontSize: '1.875rem', margin: '0 0 0.25rem' }}>{product.name}</h1>
              <p style={{ color: 'var(--text-muted)', margin: '0 0 0.75rem', fontSize: '0.875rem' }}>Model: {product.model}</p>
              <p style={{ color: 'var(--text-secondary)', margin: 0, fontSize: '0.975rem', lineHeight: 1.7 }}>{product.shortDescription}</p>
            </div>

            {/* Price summary */}
            {cheapestPrice !== null && (
              <div style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.2)', borderRadius: 'var(--radius)', padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Starting from</div>
                  <div className="price-tag">{formatINR(cheapestPrice)}</div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Available at</div>
                  <div style={{ fontWeight: 700, fontSize: '1.25rem' }}>{listings.filter(l => l.isAvailable).length} stores</div>
                </div>
              </div>
            )}

            {/* Specs */}
            <div className="card" style={{ marginBottom: '1.5rem' }}>
              <button
                onClick={() => setSpecsOpen(o => !o)}
                style={{ width: '100%', padding: '1rem 1.25rem', background: 'none', border: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', color: 'var(--text-primary)' }}
              >
                <span style={{ fontWeight: 700 }}>Specifications</span>
                {specsOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
              </button>
              {specsOpen && (
                <div style={{ padding: '0 1.25rem 1.25rem' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                    {product.specs.map((spec, i) => (
                      <div key={i} style={{ padding: '0.5rem 0.75rem', background: 'var(--bg)', borderRadius: 8 }}>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '0.2rem' }}>{spec.label}</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 500 }}>{spec.value}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Store listings (price comparison table) */}
            <div style={{ marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h2 style={{ margin: 0, fontSize: '1.25rem' }}>Price Comparison</h2>
                <Link to={`/compare/${product.id}`} className="btn btn-secondary btn-sm">Full Comparison <TrendingUp size={14} /></Link>
              </div>

              {listings.length === 0 ? (
                <div className="empty-state" style={{ padding: '2rem' }}>
                  <h3>No listings</h3>
                  <p>No stores have this product in the demo dataset.</p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {listings.map(listing => (
                    <div
                      key={listing.id}
                      className="card"
                      onClick={() => setSelectedListingId(listing.id)}
                      style={{
                        padding: '1rem 1.25rem', cursor: 'pointer',
                        border: selectedListingId === listing.id ? '1px solid var(--emerald)' : '1px solid var(--border)',
                        boxShadow: selectedListingId === listing.id ? 'var(--shadow-glow)' : 'none',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
                          <div style={{
                            width: 40, height: 40, borderRadius: 10,
                            background: `${listing.store.accentColor}22`,
                            border: `1.5px solid ${listing.store.accentColor}66`,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontWeight: 800, fontSize: '0.8rem', color: listing.store.accentColor,
                            fontFamily: 'Space Grotesk, sans-serif', flexShrink: 0
                          }}>
                            {listing.store.logoInitials}
                          </div>
                          <div>
                            <Link to={`/stores/${listing.store.id}`} onClick={e => e.stopPropagation()} style={{ fontWeight: 600, fontSize: '0.9rem' }}>
                              {listing.store.name}
                            </Link>
                            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                              <MapPin size={11} /> {listing.store.city} · {listing.configuration}
                            </div>
                          </div>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
                          <div>
                            <div className="price-tag-sm">{formatINR(listing.price)}</div>
                            {listing.price === cheapestPrice && listing.isAvailable && (
                              <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>Lowest</span>
                            )}
                          </div>
                          <span className="badge" style={{ background: `${stockColor(listing.stockStatus)}22`, color: stockColor(listing.stockStatus) }}>
                            {stockLabel(listing.stockStatus)}
                          </span>
                          {listing.isAvailable && (
                            <Link to={`/reserve/${listing.id}`} className="btn btn-primary btn-sm" onClick={e => e.stopPropagation()}>Reserve</Link>
                          )}
                        </div>
                      </div>
                      {listing.notes && (
                        <div style={{ marginTop: '0.6rem', fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <AlertCircle size={12} /> {listing.notes}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right: TrueCost widget + store quick info */}
          <div style={{ position: 'sticky', top: 80, display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {/* Store selector */}
            {listings.length > 0 && (
              <div className="card-elevated" style={{ padding: '1rem' }}>
                <label className="form-label">Calculate cost for store</label>
                <select
                  className="form-select"
                  value={selectedListingId || ''}
                  onChange={e => setSelectedListingId(e.target.value)}
                >
                  {listings.map(l => (
                    <option key={l.id} value={l.id}>{l.store.name} — {formatINR(l.price)}</option>
                  ))}
                </select>
              </div>
            )}

            {selectedListing && <TrueCostWidget listing={selectedListing} />}

            {selectedListing && (
              <div className="card" style={{ padding: '1rem 1.25rem' }}>
                <h3 style={{ margin: '0 0 0.75rem', fontSize: '0.9rem' }}>Store Details</h3>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'flex-start' }}>
                    <MapPin size={14} style={{ color: 'var(--emerald)', flexShrink: 0, marginTop: 2 }} />
                    <span>{selectedListing.store.address}, {selectedListing.store.city} {selectedListing.store.pincode}</span>
                  </div>
                  <div style={{ display: 'flex', gap: '0.4rem' }}>
                    <Clock size={14} style={{ color: 'var(--emerald)', flexShrink: 0, marginTop: 2 }} />
                    <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>Hours: illustrative — confirm with store</span>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.875rem', flexWrap: 'wrap' }}>
                  <a
                    href={mapsLink(selectedListing.store.coordinates.lat, selectedListing.store.coordinates.lng, selectedListing.store.address)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-secondary btn-sm"
                    style={{ flex: 1 }}
                  >
                    <ExternalLink size={13} /> Maps
                  </a>
                  <Link to={`/stores/${selectedListing.store.id}`} className="btn btn-secondary btn-sm" style={{ flex: 1 }}>
                    Store page
                  </Link>
                </div>
                <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', margin: '0.75rem 0 0' }}>
                  ⚠ Prices updated: {formatDateTime(selectedListing.lastUpdated)} — DEMO DATA
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .container > div[style*="gridTemplateColumns: 1fr 380px"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
