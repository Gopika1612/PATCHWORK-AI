import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft, CheckCircle, AlertCircle, Calendar,
  Clock, User, Phone, Mail, MapPin, Package
} from 'lucide-react';
import {
  getListingById, getProductById, getStoreById, createReservation
} from '../services/dataService';
import { TrueCostWidget, Toast } from '../components/Shared';
import type { StoreListing, Product, Store } from '../types';
import { formatINR, formatDate, mapsLink } from '../utils/helpers';

interface FormData {
  name: string;
  phone: string;
  email: string;
  visitDate: string;
  visitTime: string;
  notes: string;
}

interface FormErrors {
  name?: string;
  phone?: string;
  email?: string;
  visitDate?: string;
  visitTime?: string;
}

const TIME_SLOTS = [
  '10:00', '10:30', '11:00', '11:30', '12:00', '12:30',
  '13:00', '13:30', '14:00', '14:30', '15:00', '15:30',
  '16:00', '16:30', '17:00', '17:30', '18:00', '18:30',
  '19:00', '19:30',
];

function validateEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePhone(phone: string) {
  return /^[+]?[\d\s\-()]{7,15}$/.test(phone);
}

function getMinDate() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

function getMaxDate() {
  const d = new Date();
  d.setDate(d.getDate() + 30);
  return d.toISOString().slice(0, 10);
}

export default function ReservationPage() {
  const { listingId } = useParams<{ listingId: string }>();
  const navigate = useNavigate();

  const [listing, setListing] = useState<StoreListing | null>(null);
  const [product, setProduct] = useState<Product | null>(null);
  const [store, setStore] = useState<Store | null>(null);
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [form, setForm] = useState<FormData>({ name: '', phone: '', email: '', visitDate: '', visitTime: '', notes: '' });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [confirmedRef, setConfirmedRef] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (!listingId) return;
    const l = getListingById(listingId);
    if (!l) return;
    setListing(l);
    setProduct(getProductById(l.productId) || null);
    setStore(getStoreById(l.storeId) || null);
  }, [listingId]);

  if (!listing || !product || !store) {
    return (
      <div className="page-wrapper"><div className="container">
        <div className="empty-state">
          <div className="empty-state-icon">📋</div>
          <h3>Listing not found</h3>
          <p>This product listing doesn't exist.</p>
          <Link to="/products" className="btn btn-primary" style={{ marginTop: '1rem' }}>Browse Products</Link>
        </div>
      </div></div>
    );
  }

  if (!listing.isAvailable) {
    return (
      <div className="page-wrapper"><div className="container">
        <div className="empty-state">
          <AlertCircle size={48} style={{ color: 'var(--accent-red)', marginBottom: '1rem' }} />
          <h3>Not available for reservation</h3>
          <p>This listing is currently unavailable. Try another store.</p>
          <Link to={`/products/${product.id}`} className="btn btn-primary" style={{ marginTop: '1rem' }}>Back to Product</Link>
        </div>
      </div></div>
    );
  }

  const updateForm = (field: keyof FormData, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
    setErrors(prev => ({ ...prev, [field]: undefined }));
  };

  const validateStep1 = (): boolean => {
    const errs: FormErrors = {};
    if (!form.name.trim() || form.name.trim().length < 2) errs.name = 'Please enter your full name (min 2 characters).';
    if (!validatePhone(form.phone)) errs.phone = 'Enter a valid phone number.';
    if (!validateEmail(form.email)) errs.email = 'Enter a valid email address.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const validateStep2 = (): boolean => {
    const errs: FormErrors = {};
    if (!form.visitDate) errs.visitDate = 'Please select a visit date.';
    if (!form.visitTime) errs.visitTime = 'Please select a visit time.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const res = createReservation({
        listingId: listing.id,
        productId: product.id,
        storeId: store.id,
        customerName: form.name.trim(),
        customerPhone: form.phone.trim(),
        customerEmail: form.email.trim(),
        visitDate: form.visitDate,
        visitTime: form.visitTime,
        notes: form.notes.trim(),
        configuration: listing.configuration,
      });
      setConfirmedRef(res.referenceNumber);
      setStep(3);
    } catch (e) {
      setToast({ msg: 'Failed to create reservation. Please try again.', type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  if (step === 3 && confirmedRef) {
    return (
      <div className="page-wrapper">
        <div className="container" style={{ maxWidth: 600 }}>
          <div className="card-elevated" style={{ padding: '2.5rem', textAlign: 'center' }}>
            <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'rgba(16,185,129,0.15)', border: '2px solid var(--emerald)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem' }}>
              <CheckCircle size={32} color="var(--emerald)" />
            </div>
            <h1 style={{ fontSize: '1.75rem', margin: '0 0 0.5rem' }}>Reservation Submitted!</h1>
            <p style={{ color: 'var(--text-secondary)', margin: '0 0 1.5rem' }}>
              Your demo reservation is pending retailer confirmation.
            </p>
            <div style={{ background: 'var(--bg)', borderRadius: 'var(--radius)', padding: '1rem 1.5rem', marginBottom: '1.5rem', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.5rem' }}>Reference Number</div>
              <div style={{ fontFamily: 'Space Grotesk, monospace', fontSize: '1.4rem', fontWeight: 800, color: 'var(--emerald)', letterSpacing: '0.05em' }}>{confirmedRef}</div>
            </div>
            <div style={{ textAlign: 'left', background: 'var(--bg)', borderRadius: 'var(--radius)', padding: '1rem 1.25rem', marginBottom: '1.5rem', border: '1px solid var(--border)' }}>
              {[
                ['Product', product.name],
                ['Configuration', listing.configuration],
                ['Store', store.name],
                ['Address', `${store.address}, ${store.city}`],
                ['Visit', `${formatDate(form.visitDate)} at ${form.visitTime}`],
                ['Customer', form.name],
              ].map(([label, value]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.4rem 0', borderBottom: '1px solid var(--border)', fontSize: '0.875rem', gap: '1rem' }}>
                  <span style={{ color: 'var(--text-muted)' }}>{label}</span>
                  <span style={{ fontWeight: 500, textAlign: 'right' }}>{value}</span>
                </div>
              ))}
            </div>
            <div style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 'var(--radius-sm)', padding: '0.875rem', marginBottom: '1.5rem', fontSize: '0.8rem', color: '#fcd34d', textAlign: 'left' }}>
              <strong>⚠ DEMO MODE:</strong> This is a simulated reservation. No real retailer will contact you. In a production deployment, the retailer would confirm or reject this request.
            </div>
            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link to="/reservations" className="btn btn-primary">View My Reservations</Link>
              <Link to="/products" className="btn btn-secondary">Browse More Products</Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-wrapper">
      <div className="container" style={{ maxWidth: 800 }}>
        <Link to={`/products/${product.id}`} style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '0.875rem' }}>
          <ArrowLeft size={14} /> Back to Product
        </Link>

        {/* Step indicators */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '2rem' }}>
          {[['1', 'Your Details'], ['2', 'Visit Slot'], ['3', 'Review']].map(([n, label], i) => {
            const stepNum = i + 1;
            const active = step === stepNum;
            const done = step > stepNum;
            return (
              <React.Fragment key={n}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <div style={{
                    width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: done ? 'var(--emerald)' : active ? 'rgba(16,185,129,0.2)' : 'var(--bg-elevated)',
                    border: active ? '2px solid var(--emerald)' : done ? 'none' : '1px solid var(--border)',
                    fontSize: '0.75rem', fontWeight: 700, color: done ? '#fff' : active ? 'var(--emerald)' : 'var(--text-muted)'
                  }}>
                    {done ? '✓' : n}
                  </div>
                  <span style={{ fontSize: '0.8rem', fontWeight: active ? 600 : 400, color: active ? 'var(--text-primary)' : 'var(--text-muted)' }}>{label}</span>
                </div>
                {i < 2 && <div style={{ flex: 1, height: 1, background: step > i + 1 ? 'var(--emerald)' : 'var(--border)' }} />}
              </React.Fragment>
            );
          })}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '1.5rem', alignItems: 'start' }}>
          {/* Form */}
          <div className="card-elevated" style={{ padding: '1.75rem' }}>
            {step === 1 && (
              <>
                <h2 style={{ margin: '0 0 1.5rem', fontSize: '1.25rem' }}>Your Contact Details</h2>
                <div className="form-group">
                  <label className="form-label"><User size={12} style={{ display: 'inline', marginRight: 4 }} />Full Name *</label>
                  <input className={`form-input ${errors.name ? 'error' : ''}`} type="text" placeholder="Your full name" value={form.name} onChange={e => updateForm('name', e.target.value)} id="res-name" />
                  {errors.name && <div className="form-error">{errors.name}</div>}
                </div>
                <div className="form-group">
                  <label className="form-label"><Phone size={12} style={{ display: 'inline', marginRight: 4 }} />Phone Number *</label>
                  <input className={`form-input ${errors.phone ? 'error' : ''}`} type="tel" placeholder="+91 98000 00000" value={form.phone} onChange={e => updateForm('phone', e.target.value)} id="res-phone" />
                  {errors.phone && <div className="form-error">{errors.phone}</div>}
                </div>
                <div className="form-group">
                  <label className="form-label"><Mail size={12} style={{ display: 'inline', marginRight: 4 }} />Email Address *</label>
                  <input className={`form-input ${errors.email ? 'error' : ''}`} type="email" placeholder="you@example.com" value={form.email} onChange={e => updateForm('email', e.target.value)} id="res-email" />
                  {errors.email && <div className="form-error">{errors.email}</div>}
                </div>
                <div className="form-group">
                  <label className="form-label">Notes (optional)</label>
                  <textarea className="form-textarea" placeholder="Any special requests or questions for the store…" value={form.notes} onChange={e => updateForm('notes', e.target.value)} style={{ minHeight: 80 }} />
                </div>
                <div style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.15)', borderRadius: 8, padding: '0.75rem', fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '1.25rem' }}>
                  ⚠ Demo: We collect only the minimum info for this demonstration. No payment is taken. Do not enter real sensitive data.
                </div>
                <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => validateStep1() && setStep(2)}>
                  Next: Choose Visit Slot →
                </button>
              </>
            )}

            {step === 2 && (
              <>
                <h2 style={{ margin: '0 0 1.5rem', fontSize: '1.25rem' }}>Select Visit Date & Time</h2>
                <div className="form-group">
                  <label className="form-label"><Calendar size={12} style={{ display: 'inline', marginRight: 4 }} />Visit Date *</label>
                  <input className={`form-input ${errors.visitDate ? 'error' : ''}`} type="date" min={getMinDate()} max={getMaxDate()} value={form.visitDate} onChange={e => updateForm('visitDate', e.target.value)} id="res-date" />
                  {errors.visitDate && <div className="form-error">{errors.visitDate}</div>}
                </div>
                <div className="form-group">
                  <label className="form-label"><Clock size={12} style={{ display: 'inline', marginRight: 4 }} />Preferred Time Slot *</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.4rem' }}>
                    {TIME_SLOTS.map(t => (
                      <button
                        key={t}
                        onClick={() => updateForm('visitTime', t)}
                        className="btn"
                        style={{
                          padding: '0.4rem 0.25rem', fontSize: '0.8rem', borderRadius: 8,
                          background: form.visitTime === t ? 'var(--emerald)' : 'var(--bg)',
                          color: form.visitTime === t ? '#fff' : 'var(--text-secondary)',
                          border: form.visitTime === t ? 'none' : '1px solid var(--border)',
                        }}
                        id={`time-${t}`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                  {errors.visitTime && <div className="form-error" style={{ marginTop: '0.5rem' }}>{errors.visitTime}</div>}
                </div>

                <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.25rem' }}>
                  <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => setStep(1)}>← Back</button>
                  <button className="btn btn-primary" style={{ flex: 2 }} onClick={() => { if (validateStep2()) setStep(3 as any); }}>
                    Review Reservation →
                  </button>
                </div>
              </>
            )}

            {(step as number) === 3 && (
              <>
                <h2 style={{ margin: '0 0 1.5rem', fontSize: '1.25rem' }}>Review & Confirm</h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1.5rem' }}>
                  {[
                    ['Product', product.name],
                    ['Configuration', listing.configuration],
                    ['Store', `${store.name}, ${store.city}`],
                    ['Visit Date', form.visitDate ? formatDate(form.visitDate) : '—'],
                    ['Visit Time', form.visitTime],
                    ['Name', form.name],
                    ['Phone', form.phone],
                    ['Email', form.email],
                    ...(form.notes ? [['Notes', form.notes]] : []),
                  ].map(([label, value]) => (
                    <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.5rem 0', borderBottom: '1px solid var(--border)', fontSize: '0.875rem', gap: '0.75rem' }}>
                      <span style={{ color: 'var(--text-muted)', flexShrink: 0 }}>{label}</span>
                      <span style={{ fontWeight: 500, textAlign: 'right' }}>{value}</span>
                    </div>
                  ))}
                </div>
                <div style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 8, padding: '0.875rem', fontSize: '0.8rem', color: '#fcd34d', marginBottom: '1.25rem' }}>
                  <strong>No payment collected.</strong> This is a demo reservation. The retailer will need to confirm your visit. In real use, they would call or email you.
                </div>
                <div style={{ display: 'flex', gap: '0.75rem' }}>
                  <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => setStep(2)}>← Edit</button>
                  <button className="btn btn-primary" style={{ flex: 2 }} onClick={handleSubmit} disabled={submitting}>
                    {submitting ? 'Submitting…' : '✓ Confirm Reservation'}
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Sidebar: product/store summary */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div className="card" style={{ padding: '1.25rem' }}>
              <h3 style={{ margin: '0 0 0.875rem', fontSize: '0.9rem', fontWeight: 700 }}>Reserving</h3>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <div style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)' }}>{product.name}</div>
                <div style={{ color: 'var(--text-muted)' }}>{listing.configuration}</div>
                <div className="divider" style={{ margin: '0.25rem 0' }} />
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <div style={{ width: 24, height: 24, borderRadius: 6, background: `${store.accentColor}22`, border: `1px solid ${store.accentColor}66`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.65rem', fontWeight: 800, color: store.accentColor }}>
                    {store.logoInitials}
                  </div>
                  <span style={{ fontWeight: 500 }}>{store.name}</span>
                </div>
                <div style={{ display: 'flex', gap: '0.35rem', alignItems: 'flex-start' }}>
                  <MapPin size={12} style={{ flexShrink: 0, marginTop: 2, color: 'var(--emerald)' }} />
                  <span>{store.address}, {store.city}</span>
                </div>
                <div className="divider" style={{ margin: '0.25rem 0' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Listed Price</span>
                  <span className="text-emerald" style={{ fontWeight: 700 }}>{formatINR(listing.price)}</span>
                </div>
              </div>
            </div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', padding: '0.75rem', background: 'rgba(107,114,128,0.06)', borderRadius: 8, border: '1px solid var(--border)' }}>
              ⚠ No payment is requested now. This reserve-for-inspection service is free. Confirm price and availability directly with the store at the time of visit.
            </div>
          </div>
        </div>

        {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}

        <style>{`
          .form-input.error { border-color: var(--accent-red); }
          @media (max-width: 768px) {
            .container > div[style*="gridTemplateColumns: 1fr 320px"] {
              grid-template-columns: 1fr !important;
            }
          }
        `}</style>
      </div>
    </div>
  );
}
