import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, RefreshCw, Database, Package, Store, BookOpen, CheckCircle } from 'lucide-react';
import {
  getProducts, getStores, getListings, getReservations, resetDemoData
} from '../services/dataService';
import { Toast } from '../components/Shared';
import type { DemoUser } from '../types';
import { formatDateTime } from '../utils/helpers';

interface AdminPageProps {
  user: DemoUser;
}

export default function AdminPage({ user }: AdminPageProps) {
  const [stats, setStats] = useState({ products: 0, stores: 0, listings: 0, reservations: 0 });
  const [reservations, setReservations] = useState<ReturnType<typeof getReservations>>([]);
  const [listings, setListings] = useState<ReturnType<typeof getListings>>([]);
  const [confirmReset, setConfirmReset] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [tab, setTab] = useState<'overview' | 'reservations' | 'listings'>('overview');

  const load = () => {
    const ps = getProducts();
    const ss = getStores();
    const ls = getListings();
    const rs = getReservations();
    setStats({ products: ps.length, stores: ss.length, listings: ls.length, reservations: rs.length });
    setReservations([...rs].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    setListings(ls);
  };

  useEffect(() => { load(); }, []);

  if (user.role !== 'admin') {
    return (
      <div className="page-wrapper"><div className="container">
        <div className="empty-state">
          <AlertTriangle size={40} style={{ color: 'var(--accent-amber)' }} />
          <h3>Admin access required</h3>
          <p>Switch to the Admin demo account using the navbar account switcher.</p>
          <Link to="/" className="btn btn-primary" style={{ marginTop: '1rem' }}>Go Home</Link>
        </div>
      </div></div>
    );
  }

  const handleReset = () => {
    resetDemoData();
    setToast({ msg: '✓ Demo data restored to original seed.', type: 'success' });
    setConfirmReset(false);
    load();
  };

  const STATUS_COLORS: Record<string, string> = {
    pending: '#fcd34d', confirmed: '#34d399', rejected: '#fca5a5', cancelled: '#9ca3af', completed: '#a5b4fc',
  };

  const byStatus = (status: string) => reservations.filter(r => r.status === status).length;

  return (
    <div className="page-wrapper">
      <div className="container">
        {/* Header */}
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <span className="badge badge-amber">ADMIN PANEL</span>
            <span className="badge badge-red">DEMO ONLY</span>
          </div>
          <h1 style={{ margin: '0 0 0.25rem' }}>Demo Data Administration</h1>
          <p style={{ color: 'var(--text-secondary)', margin: 0 }}>
            Inspect and manage demo data. Reset to original seed if needed.
          </p>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: '0', marginBottom: '1.5rem', borderBottom: '1px solid var(--border)' }}>
          {[['overview', 'Overview'], ['reservations', 'Reservations'], ['listings', 'Listings']].map(([val, label]) => (
            <button key={val} onClick={() => setTab(val as any)}
              style={{
                padding: '0.75rem 1.25rem', background: 'none', border: 'none', cursor: 'pointer',
                fontSize: '0.9rem', fontWeight: 600, fontFamily: 'inherit',
                color: tab === val ? 'var(--emerald)' : 'var(--text-muted)',
                borderBottom: tab === val ? '2px solid var(--emerald)' : '2px solid transparent',
                marginBottom: -1,
              }}
            >{label}</button>
          ))}
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <button className="btn btn-secondary btn-sm" onClick={load} style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <RefreshCw size={13} /> Refresh
            </button>
          </div>
        </div>

        {tab === 'overview' && (
          <>
            {/* Stats */}
            <div className="grid-4" style={{ marginBottom: '2rem' }}>
              <div className="stat-card">
                <Database size={20} style={{ color: 'var(--emerald)', margin: '0 auto 0.5rem' }} />
                <div className="stat-value">{stats.products}</div>
                <div className="stat-label">Products</div>
              </div>
              <div className="stat-card">
                <Store size={20} style={{ color: 'var(--accent-indigo)', margin: '0 auto 0.5rem' }} />
                <div className="stat-value" style={{ color: 'var(--accent-indigo)' }}>{stats.stores}</div>
                <div className="stat-label">Stores</div>
              </div>
              <div className="stat-card">
                <Package size={20} style={{ color: 'var(--accent-amber)', margin: '0 auto 0.5rem' }} />
                <div className="stat-value" style={{ color: 'var(--accent-amber)' }}>{stats.listings}</div>
                <div className="stat-label">Listings</div>
              </div>
              <div className="stat-card">
                <BookOpen size={20} style={{ color: 'var(--accent-purple)', margin: '0 auto 0.5rem' }} />
                <div className="stat-value" style={{ color: 'var(--accent-purple)' }}>{stats.reservations}</div>
                <div className="stat-label">Reservations</div>
              </div>
            </div>

            {/* Reservation breakdown */}
            <div className="card-elevated" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
              <h3 style={{ margin: '0 0 1rem' }}>Reservation Summary</h3>
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                {['pending', 'confirmed', 'rejected', 'cancelled', 'completed'].map(s => (
                  <div key={s} style={{ textAlign: 'center', minWidth: 80 }}>
                    <div style={{ fontSize: '1.5rem', fontWeight: 800, color: STATUS_COLORS[s] }}>{byStatus(s)}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', textTransform: 'capitalize' }}>{s}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Reset data */}
            <div className="card" style={{ padding: '1.5rem', border: '1px solid rgba(239,68,68,0.2)' }}>
              <h3 style={{ margin: '0 0 0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <AlertTriangle size={18} color="var(--accent-red)" /> Reset Demo Data
              </h3>
              <p style={{ color: 'var(--text-secondary)', margin: '0 0 1rem', fontSize: '0.875rem' }}>
                This will restore all products, stores, listings, and reservations to the original seed dataset. All changes (new reservations, edited listings) will be permanently lost.
              </p>
              {confirmReset ? (
                <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
                  <span style={{ color: '#fca5a5', fontSize: '0.875rem' }}>Are you sure? This cannot be undone.</span>
                  <button className="btn btn-danger" onClick={handleReset}>Yes, Reset Everything</button>
                  <button className="btn btn-ghost" onClick={() => setConfirmReset(false)}>Cancel</button>
                </div>
              ) : (
                <button className="btn btn-secondary" onClick={() => setConfirmReset(true)} style={{ color: 'var(--accent-red)', borderColor: 'rgba(239,68,68,0.3)' }}>
                  <RefreshCw size={14} /> Restore Original Data
                </button>
              )}
            </div>
          </>
        )}

        {tab === 'reservations' && (
          <div>
            <h2 style={{ margin: '0 0 1rem', fontSize: '1.25rem' }}>All Reservations ({reservations.length})</h2>
            {reservations.length === 0 ? (
              <div className="empty-state"><h3>No reservations</h3></div>
            ) : (
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>Reference</th>
                      <th>Product</th>
                      <th>Store</th>
                      <th>Customer</th>
                      <th>Visit</th>
                      <th>Status</th>
                      <th>Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reservations.map(r => (
                      <tr key={r.id}>
                        <td><span style={{ fontFamily: 'monospace', fontSize: '0.78rem' }}>{r.referenceNumber}</span></td>
                        <td><Link to={`/products/${r.productId}`} style={{ color: 'var(--emerald)', fontSize: '0.85rem' }}>{r.productId}</Link></td>
                        <td style={{ fontSize: '0.85rem' }}>{r.storeId}</td>
                        <td style={{ fontSize: '0.85rem' }}>{r.customerName}</td>
                        <td style={{ fontSize: '0.82rem' }}>{r.visitDate} {r.visitTime}</td>
                        <td><span className="badge" style={{ background: `${STATUS_COLORS[r.status]}22`, color: STATUS_COLORS[r.status] }}>{r.status}</span></td>
                        <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{formatDateTime(r.createdAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {tab === 'listings' && (
          <div>
            <h2 style={{ margin: '0 0 1rem', fontSize: '1.25rem' }}>All Listings ({listings.length})</h2>
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Product</th>
                    <th>Store</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Qty</th>
                    <th>Available</th>
                    <th>Updated</th>
                  </tr>
                </thead>
                <tbody>
                  {listings.map(l => (
                    <tr key={l.id}>
                      <td style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'monospace' }}>{l.id}</td>
                      <td><Link to={`/products/${l.productId}`} style={{ color: 'var(--emerald)', fontSize: '0.85rem' }}>{l.productId}</Link></td>
                      <td style={{ fontSize: '0.82rem' }}>{l.storeId}</td>
                      <td style={{ fontWeight: 600 }}>₹{l.price.toLocaleString('en-IN')}</td>
                      <td><span style={{ color: l.stockStatus === 'in_stock' ? 'var(--emerald)' : l.stockStatus === 'low_stock' ? 'var(--accent-amber)' : 'var(--accent-red)', fontSize: '0.82rem' }}>{l.stockStatus}</span></td>
                      <td style={{ fontSize: '0.85rem' }}>{l.stockQty}</td>
                      <td>{l.isAvailable ? <CheckCircle size={14} color="var(--emerald)" /> : <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>No</span>}</td>
                      <td style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{formatDateTime(l.lastUpdated)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      </div>
    </div>
  );
}
