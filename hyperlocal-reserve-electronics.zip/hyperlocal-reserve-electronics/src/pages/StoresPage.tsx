import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Clock, Phone, Mail, ExternalLink } from 'lucide-react';
import { getStores, getListings } from '../services/dataService';
import { StoreCard } from '../components/Shared';
import type { Store } from '../types';

export default function StoresPage() {
  const [stores, setStores] = useState<(Store & { listingCount: number })[]>([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    const allStores = getStores();
    const allListings = getListings();
    const enriched = allStores.map(s => ({
      ...s,
      listingCount: allListings.filter(l => l.storeId === s.id && l.isAvailable).length,
    }));
    setStores(enriched);
  }, []);

  const filtered = stores.filter(s =>
    !query || s.name.toLowerCase().includes(query.toLowerCase()) || s.city.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="page-wrapper">
      <div className="container">
        <div className="section-header">
          <h1 className="section-title">Demo Electronics Stores</h1>
          <p className="section-subtitle">Fictional retailer profiles — all contact details are illustrative</p>
        </div>

        <div style={{ marginBottom: '1.5rem' }}>
          <input
            className="form-input"
            type="text"
            placeholder="Search by store name or city…"
            value={query}
            onChange={e => setQuery(e.target.value)}
            style={{ maxWidth: 400 }}
            id="stores-search"
          />
        </div>

        {filtered.length === 0 ? (
          <div className="empty-state"><h3>No stores found</h3><p>Try a different search.</p></div>
        ) : (
          <div className="grid-3">
            {filtered.map(s => <StoreCard key={s.id} store={s} listingCount={s.listingCount} />)}
          </div>
        )}
      </div>
    </div>
  );
}
