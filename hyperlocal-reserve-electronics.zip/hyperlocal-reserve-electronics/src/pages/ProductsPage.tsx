import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X, MapPin } from 'lucide-react';
import { searchProducts, ensureSeeded } from '../services/dataService';
import { ProductCard } from '../components/Shared';
import type { SearchFilters, Category, UserLocation, StockStatus } from '../types';

const CATEGORIES: { id: Category; label: string }[] = [
  { id: 'laptops', label: 'Laptops' },
  { id: 'smartphones', label: 'Smartphones' },
  { id: 'tablets', label: 'Tablets' },
  { id: 'monitors', label: 'Monitors' },
  { id: 'accessories', label: 'Accessories' },
  { id: 'gaming', label: 'Gaming' },
];

const SORT_OPTIONS = [
  { value: 'relevance', label: 'Relevance' },
  { value: 'price_asc', label: 'Price: Low to High' },
  { value: 'price_desc', label: 'Price: High to Low' },
  { value: 'distance', label: 'Distance (nearest)' },
];

const defaultFilters: SearchFilters = {
  query: '',
  category: '',
  brand: '',
  minPrice: '',
  maxPrice: '',
  stockStatus: '',
  sortBy: 'relevance',
};

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState<SearchFilters>({
    ...defaultFilters,
    query: searchParams.get('q') || '',
    category: (searchParams.get('category') as Category) || '',
  });
  const [results, setResults] = useState<ReturnType<typeof searchProducts>>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [location, setLocation] = useState<UserLocation | null>(null);
  const [locLoading, setLocLoading] = useState(false);

  useEffect(() => { ensureSeeded(); }, []);

  const runSearch = useCallback(() => {
    const res = searchProducts(filters, location);
    setResults(res);
  }, [filters, location]);

  useEffect(() => { runSearch(); }, [runSearch]);

  const updateFilter = <K extends keyof SearchFilters>(key: K, value: SearchFilters[K]) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const requestLocation = () => {
    if (!navigator.geolocation) return;
    setLocLoading(true);
    navigator.geolocation.getCurrentPosition(
      pos => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude, granted: true });
        setLocLoading(false);
      },
      () => {
        setLocation({ lat: 0, lng: 0, granted: false });
        setLocLoading(false);
      }
    );
  };

  const clearFilters = () => {
    setFilters({ ...defaultFilters, query: filters.query });
  };

  const hasActiveFilters = filters.category || filters.brand || filters.minPrice !== '' || filters.maxPrice !== '' || filters.stockStatus;

  return (
    <div className="page-wrapper">
      <div className="container">
        {/* Header */}
        <div className="section-header">
          <h1 className="section-title">Browse Electronics</h1>
          <p className="section-subtitle">Search across {results.length} matching product{results.length !== 1 ? 's' : ''} — DEMO DATA</p>
        </div>

        {/* Search bar */}
        <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 240, position: 'relative' }}>
            <Search size={18} style={{ position: 'absolute', left: '0.875rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              className="form-input"
              type="text"
              placeholder="Search by name, brand, model…"
              value={filters.query}
              onChange={e => updateFilter('query', e.target.value)}
              style={{ paddingLeft: '2.75rem' }}
              id="product-search"
              aria-label="Search products"
            />
          </div>
          <select
            className="form-select"
            value={filters.sortBy}
            onChange={e => updateFilter('sortBy', e.target.value as SearchFilters['sortBy'])}
            style={{ width: 'auto', minWidth: 180 }}
            aria-label="Sort by"
          >
            {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <button className={`btn ${showFilters ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setShowFilters(f => !f)} style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <SlidersHorizontal size={16} /> Filters {hasActiveFilters && '•'}
          </button>
          <button className="btn btn-secondary" onClick={requestLocation} disabled={locLoading} style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <MapPin size={16} style={{ color: location?.granted ? 'var(--emerald)' : undefined }} />
            {locLoading ? 'Locating…' : location?.granted ? 'Location on' : 'Use location'}
          </button>
        </div>

        {/* Category quick-filter pills */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
          <button
            className={`badge ${filters.category === '' ? 'badge-emerald' : 'badge-gray'}`}
            onClick={() => updateFilter('category', '')}
            style={{ cursor: 'pointer', border: 'none', padding: '0.3rem 0.75rem', fontSize: '0.8rem', background: filters.category === '' ? 'rgba(16,185,129,0.2)' : undefined }}
          >
            All
          </button>
          {CATEGORIES.map(c => (
            <button
              key={c.id}
              className={`badge ${filters.category === c.id ? 'badge-emerald' : 'badge-gray'}`}
              onClick={() => updateFilter('category', filters.category === c.id ? '' : c.id)}
              style={{ cursor: 'pointer', border: 'none', padding: '0.3rem 0.75rem', fontSize: '0.8rem', background: filters.category === c.id ? 'rgba(16,185,129,0.2)' : undefined, textTransform: 'capitalize' }}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Expanded filters panel */}
        {showFilters && (
          <div className="card-elevated" style={{ padding: '1.25rem', marginBottom: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h3 style={{ margin: 0, fontSize: '0.9rem', fontWeight: 700 }}>Advanced Filters</h3>
              {hasActiveFilters && (
                <button className="btn btn-ghost btn-sm" onClick={clearFilters}>
                  <X size={14} /> Clear all
                </button>
              )}
            </div>
            <div className="grid-4">
              <div className="form-group">
                <label className="form-label">Brand</label>
                <input className="form-input" type="text" placeholder="e.g. NovaTech" value={filters.brand} onChange={e => updateFilter('brand', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Min Price (₹)</label>
                <input className="form-input" type="number" min={0} placeholder="e.g. 20000" value={filters.minPrice} onChange={e => updateFilter('minPrice', e.target.value === '' ? '' : Number(e.target.value))} />
              </div>
              <div className="form-group">
                <label className="form-label">Max Price (₹)</label>
                <input className="form-input" type="number" min={0} placeholder="e.g. 100000" value={filters.maxPrice} onChange={e => updateFilter('maxPrice', e.target.value === '' ? '' : Number(e.target.value))} />
              </div>
              <div className="form-group">
                <label className="form-label">Availability</label>
                <select className="form-select" value={filters.stockStatus} onChange={e => updateFilter('stockStatus', e.target.value as StockStatus | '')}>
                  <option value="">Any</option>
                  <option value="in_stock">In Stock</option>
                  <option value="low_stock">Low Stock</option>
                  <option value="out_of_stock">Out of Stock</option>
                  <option value="display_only">Display Only</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Results */}
        {results.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">🔍</div>
            <h3>No products found</h3>
            <p>Try a different search term or remove some filters.</p>
            <button className="btn btn-primary" style={{ marginTop: '1rem' }} onClick={clearFilters}>Clear Filters</button>
          </div>
        ) : (
          <div className="grid-3">
            {results.map(p => (
              <ProductCard key={p.id} product={p} minPrice={p.minPrice} storeCount={p.storeCount} distanceKm={p.distanceKm} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
