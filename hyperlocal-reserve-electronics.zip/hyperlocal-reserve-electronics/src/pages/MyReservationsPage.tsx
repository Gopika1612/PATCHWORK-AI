import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Package, MapPin, XCircle, RefreshCw } from 'lucide-react';
import {
  getReservations, getProductById, getStoreById, updateReservationStatus
} from '../services/dataService';
import { ReservationStatusBadge, Toast } from '../components/Shared';
import type { Reservation, Product, Store } from '../types';
import { formatDate, formatDateTime } from '../utils/helpers';

type EnrichedRes = Reservation & { product: Product | undefined; store: Store | undefined };

export default function MyReservationsPage() {
  const [reservations, setReservations] = useState<EnrichedRes[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [confirmCancel, setConfirmCancel] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  const load = () => {
    const all = getReservations().map(r => ({
      ...r,
      product: getProductById(r.productId),
      store: getStoreById(r.storeId),
    }));
    all.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    setReservations(all);
  };

  useEffect(() => { load(); }, []);

  const filtered = filter === 'all' ? reservations : reservations.filter(r => r.status === filter);

  const handleCancel = (id: string) => {
    setCancellingId(id);
    try {
      updateReservationStatus(id, 'cancelled');
      setToast({ msg: 'Reservation cancelled successfully.', type: 'success' });
      load();
    } catch {
      setToast({ msg: 'Failed to cancel. Please try again.', type: 'error' });
    } finally {
      setCancellingId(null);
      setConfirmCancel(null);
    }
  };

  const STATUS_FILTERS = [
    { value: 'all', label: 'All' },
    { value: 'pending', label: 'Pending' },
    { value: 'confirmed', label: 'Confirmed' },
    { value: 'cancelled', label: 'Cancelled' },
    { value: 'completed', label: 'Completed' },
    { value: 'rejected', label: 'Rejected' },
  ];

  return (
    <div className="page-wrapper">
      <div className="container">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <h1 style={{ margin: 0, fontSize: '1.75rem' }}>My Reservations</h1>
            <p style={{ color: 'var(--text-secondary)', margin: '0.25rem 0 0', fontSize: '0.875rem' }}>
              Demo reservations — persisted in browser local storage
            </p>
          </div>
          <button className="btn btn-secondary btn-sm" onClick={load} style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <RefreshCw size={14} /> Refresh
          </button>
        </div>

        {/* Status filter tabs */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
          {STATUS_FILTERS.map(f => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className="btn"
              style={{
                padding: '0.3rem 0.875rem', fontSize: '0.8rem', borderRadius: 999,
                background: filter === f.value ? 'rgba(16,185,129,0.2)' : 'var(--bg-elevated)',
                color: filter === f.value ? 'var(--emerald)' : 'var(--text-secondary)',
                border: filter === f.value ? '1px solid var(--emerald)' : '1px solid var(--border)',
              }}
            >
              {f.label}
              {f.value !== 'all' && <span style={{ marginLeft: '0.3rem', opacity: 0.7 }}>({reservations.filter(r => r.status === f.value).length})</span>}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">📋</div>
            <h3>{filter === 'all' ? 'No reservations yet' : `No ${filter} reservations`}</h3>
            <p>{filter === 'all' ? 'Reserve a product for in-store inspection to get started.' : 'Try a different filter.'}</p>
            {filter === 'all' && <Link to="/products" className="btn btn-primary" style={{ marginTop: '1rem' }}>Browse Products</Link>}
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {filtered.map(r => (
              <div key={r.id} className="card fade-in-up" style={{ padding: '1.25rem 1.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem', flexWrap: 'wrap', marginBottom: '1rem' }}>
                  <div>
                    <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.4rem', alignItems: 'center', flexWrap: 'wrap' }}>
                      <ReservationStatusBadge status={r.status} />
                      <span style={{ fontFamily: 'monospace', fontSize: '0.78rem', color: 'var(--text-muted)', background: 'var(--bg)', padding: '0.15rem 0.5rem', borderRadius: 4, border: '1px solid var(--border)' }}>
                        {r.referenceNumber}
                      </span>
                    </div>
                    <h3 style={{ margin: '0 0 0.2rem', fontSize: '1.05rem' }}>
                      {r.product?.name || r.productId}
                    </h3>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{r.configuration}</div>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    {r.product && (
                      <Link to={`/products/${r.productId}`} className="btn btn-ghost btn-sm">
                        <Package size={13} /> View Product
                      </Link>
                    )}
                    {(r.status === 'pending' || r.status === 'confirmed') && (
                      confirmCancel === r.id ? (
                        <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                          <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Cancel this?</span>
                          <button className="btn btn-danger btn-sm" onClick={() => handleCancel(r.id)} disabled={cancellingId === r.id}>Yes</button>
                          <button className="btn btn-ghost btn-sm" onClick={() => setConfirmCancel(null)}>No</button>
                        </div>
                      ) : (
                        <button className="btn btn-secondary btn-sm" onClick={() => setConfirmCancel(r.id)} style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: 'var(--accent-red)', borderColor: 'rgba(239,68,68,0.3)' }}>
                          <XCircle size={13} /> Cancel
                        </button>
                      )
                    )}
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '0.75rem' }}>
                  {r.store && (
                    <div style={{ display: 'flex', gap: '0.4rem', fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                      <MapPin size={13} style={{ color: 'var(--emerald)', flexShrink: 0, marginTop: 1 }} />
                      <div>
                        <div style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{r.store.name}</div>
                        <div style={{ color: 'var(--text-muted)' }}>{r.store.city}</div>
                      </div>
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: '0.4rem', fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                    <Calendar size={13} style={{ color: 'var(--emerald)', flexShrink: 0, marginTop: 1 }} />
                    <div>
                      <div style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{formatDate(r.visitDate)}</div>
                      <div style={{ color: 'var(--text-muted)' }}>{r.visitTime}</div>
                    </div>
                  </div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    <div>Created: {formatDateTime(r.createdAt)}</div>
                    {r.updatedAt !== r.createdAt && <div>Updated: {formatDateTime(r.updatedAt)}</div>}
                  </div>
                  {r.notes && (
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', gridColumn: '1 / -1', background: 'var(--bg)', padding: '0.4rem 0.6rem', borderRadius: 6, border: '1px solid var(--border)' }}>
                      Note: {r.notes}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', textAlign: 'center', marginTop: '2rem' }}>
          ⚠ Reservations are stored in browser local storage — they persist across refreshes but are device-specific. Clear browser data to reset.
        </p>

        {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      </div>
    </div>
  );
}
