import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft, MapPin, Phone, Mail, Clock, ExternalLink,
  Package, ShoppingBag
} from 'lucide-react';
import { getStoreById, getListingsForStore, getProductById } from '../services/dataService';
import type { Store, StoreListing, Product } from '../types';
import { formatINR, stockLabel, stockColor, mapsLink, formatDateTime } from '../utils/helpers';

export default function StoreDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [store, setStore] = useState<Store | null>(null);
  const [listings, setListings] = useState<(StoreListing & { product: Product })[]>([]);

  useEffect(() => {
    if (!id) return;
    const s = getStoreById(id);
    if (!s) return;
    setStore(s);
    const ls = getListingsForStore(id)
      .map(l => {
        const product = getProductById(l.productId);
        return product ? { ...l, product } : null;
      })
      .filter(Boolean) as (StoreListing & { product: Product })[];
    ls.sort((a, b) => a.price - b.price);
    setListings(ls);
  }, [id]);

  if (!store) {
    return (
      <div className="page-wrapper"><div className="container">
        <div className="empty-state"><h3>Store not found</h3><Link to="/stores" className="btn btn-primary">Browse Stores</Link></div>
      </div></div>
    );
  }

  return (
    <div className="page-wrapper">
      <div className="container">
        <Link to="/stores" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '0.875rem' }}>
          <ArrowLeft size={14} /> All Stores
        </Link>

        {/* Store header */}
        <div className="card-elevated" style={{ padding: '2rem', marginBottom: '2rem' }}>
          <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start', flexWrap: 'wrap' }}>
            <div style={{
              width: 72, height: 72, borderRadius: 16, flexShrink: 0,
              background: `${store.accentColor}22`,
              border: `2px solid ${store.accentColor}66`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontWeight: 900, fontSize: '1.4rem', color: store.accentColor,
              fontFamily: 'Space Grotesk, sans-serif'
            }}>
              {store.logoInitials}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.4rem', flexWrap: 'wrap' }}>
                <span className="badge badge-emerald">{listings.filter(l => l.isAvailable).length} products listed</span>
                <span className="badge badge-amber">DEMO STORE</span>
              </div>
              <h1 style={{ margin: '0 0 0.25rem', fontSize: '1.75rem' }}>{store.name}</h1>
              <p style={{ color: 'var(--text-secondary)', margin: '0 0 1rem', fontSize: '0.95rem' }}>{store.description}</p>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem', fontSize: '0.875rem' }}>
                <div style={{ display: 'flex', gap: '0.5rem', color: 'var(--text-secondary)' }}>
                  <MapPin size={15} style={{ color: 'var(--emerald)', flexShrink: 0, marginTop: 2 }} />
                  <span>{store.address}, {store.city}, {store.state} — {store.pincode}</span>
                </div>
                <div style={{ display: 'flex', gap: '0.5rem', color: 'var(--text-secondary)' }}>
                  <Phone size={15} style={{ color: 'var(--emerald)', flexShrink: 0, marginTop: 2 }} />
                  <span>{store.phone} <em style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>(demo)</em></span>
                </div>
                <div style={{ display: 'flex', gap: '0.5rem', color: 'var(--text-secondary)' }}>
                  <Mail size={15} style={{ color: 'var(--emerald)', flexShrink: 0, marginTop: 2 }} />
                  <span>{store.email} <em style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>(demo)</em></span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.25rem', flexWrap: 'wrap' }}>
                <a
                  href={mapsLink(store.coordinates.lat, store.coordinates.lng, `${store.name} ${store.address}`)}
                  target="_blank" rel="noopener noreferrer"
                  className="btn btn-secondary btn-sm"
                >
                  <ExternalLink size={13} /> Open in Maps
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Hours & Products grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: '1.5rem', alignItems: 'start' }}>
          {/* Hours */}
          <div className="card" style={{ padding: '1.25rem' }}>
            <h3 style={{ margin: '0 0 1rem', fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Clock size={16} color="var(--emerald)" /> Opening Hours
            </h3>
            <p style={{ fontSize: '0.72rem', color: 'var(--accent-amber)', margin: '0 0 0.75rem' }}>⚠ Illustrative — confirm with store</p>
            {store.hours.map((h, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.45rem 0', borderBottom: i < store.hours.length - 1 ? '1px solid var(--border)' : 'none', fontSize: '0.85rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>{h.day}</span>
                <span style={{ fontWeight: 600 }}>{h.open} – {h.close}</span>
              </div>
            ))}
          </div>

          {/* Listings */}
          <div>
            <h2 style={{ margin: '0 0 1rem', fontSize: '1.25rem' }}>
              Available Products <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)', fontWeight: 400 }}>({listings.length} listing{listings.length !== 1 ? 's' : ''})</span>
            </h2>
            {listings.length === 0 ? (
              <div className="empty-state" style={{ padding: '2rem' }}><h3>No listings</h3></div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {listings.map(l => (
                  <div key={l.id} className="card" style={{ padding: '1rem 1.25rem' }}>
                    <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap' }}>
                      <div style={{ flex: 1, minWidth: 200 }}>
                        <Link to={`/products/${l.product.id}`} style={{ fontWeight: 600, fontSize: '0.975rem', color: 'var(--text-primary)' }}>
                          {l.product.name}
                        </Link>
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>{l.configuration}</div>
                        {l.notes && <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.3rem' }}>{l.notes}</div>}
                      </div>
                      <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
                        <div className="price-tag-sm">{formatINR(l.price)}</div>
                        <span className="badge" style={{ background: `${stockColor(l.stockStatus)}22`, color: stockColor(l.stockStatus) }}>
                          {stockLabel(l.stockStatus)}
                        </span>
                        {l.isAvailable
                          ? <Link to={`/reserve/${l.id}`} className="btn btn-primary btn-sm">Reserve</Link>
                          : <span className="badge badge-gray">Unavailable</span>
                        }
                      </div>
                    </div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '0.5rem' }}>
                      Updated: {formatDateTime(l.lastUpdated)} — DEMO DATA
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <style>{`
          @media (max-width: 768px) {
            .container > div[style*="gridTemplateColumns: 280px"] {
              grid-template-columns: 1fr !important;
            }
          }
        `}</style>
      </div>
    </div>
  );
}
