import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Package, Plus, Edit2, Trash2, Check, X, Save,
  ChevronDown, ChevronUp, AlertCircle, Eye
} from 'lucide-react';
import {
  getListingsForStore, getProductById, updateListing,
  deleteListing, createListing, getProducts, getReservationsForStore,
  getProductById as getProduct, getStoreById, updateReservationStatus
} from '../services/dataService';
import { ReservationStatusBadge, Toast } from '../components/Shared';
import type { StoreListing, Product, Reservation, Store } from '../types';
import { formatINR, formatDateTime, stockLabel, stockColor } from '../utils/helpers';
import type { DemoUser } from '../types';

interface RetailerDashboardProps {
  user: DemoUser;
}

export default function RetailerDashboard({ user }: RetailerDashboardProps) {
  const storeId = user.storeId;
  const [store, setStore] = useState<Store | null>(null);
  const [listings, setListings] = useState<(StoreListing & { product: Product | undefined })[]>([]);
  const [reservations, setReservations] = useState<(Reservation & { product: Product | undefined })[]>([]);
  const [activeTab, setActiveTab] = useState<'inventory' | 'reservations'>('inventory');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<StoreListing>>({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [addForm, setAddForm] = useState({
    productId: '',
    price: '',
    stockQty: '',
    stockStatus: 'in_stock' as StoreListing['stockStatus'],
    configuration: '',
    notes: '',
    deliveryCharge: '',
  });

  const load = () => {
    if (!storeId) return;
    const s = getStoreById(storeId);
    setStore(s || null);
    const ls = getListingsForStore(storeId).map(l => ({ ...l, product: getProductById(l.productId) }));
    setListings(ls);
    const rs = getReservationsForStore(storeId).map(r => ({ ...r, product: getProductById(r.productId) }));
    rs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    setReservations(rs);
    setAllProducts(getProducts());
  };

  useEffect(() => { load(); }, [storeId]);

  if (!storeId) {
    return (
      <div className="page-wrapper"><div className="container">
        <div className="empty-state">
          <AlertCircle size={40} style={{ color: 'var(--accent-amber)' }} />
          <h3>Not a retailer account</h3>
          <p>Switch to a retailer demo account using the account switcher in the navbar.</p>
          <Link to="/" className="btn btn-primary" style={{ marginTop: '1rem' }}>Go Home</Link>
        </div>
      </div></div>
    );
  }

  const startEdit = (listing: StoreListing) => {
    setEditingId(listing.id);
    setEditForm({ ...listing });
  };

  const saveEdit = () => {
    if (!editingId) return;
    try {
      const original = listings.find(l => l.id === editingId);
      if (!original) return;
      const price = Number(editForm.price);
      if (isNaN(price) || price < 0) { setToast({ msg: 'Price must be a non-negative number.', type: 'error' }); return; }
      updateListing({ ...original, ...editForm, price } as StoreListing);
      setToast({ msg: 'Listing updated successfully.', type: 'success' });
      setEditingId(null);
      load();
    } catch (e: any) {
      setToast({ msg: e.message || 'Update failed.', type: 'error' });
    }
  };

  const handleDelete = (id: string) => {
    if (!window.confirm('Delete this listing? This cannot be undone.')) return;
    deleteListing(id);
    setToast({ msg: 'Listing deleted.', type: 'info' });
    load();
  };

  const handleAdd = () => {
    if (!addForm.productId) { setToast({ msg: 'Please select a product.', type: 'error' }); return; }
    const price = Number(addForm.price);
    if (isNaN(price) || price <= 0) { setToast({ msg: 'Price must be positive.', type: 'error' }); return; }
    const stockQty = Number(addForm.stockQty);
    createListing({
      productId: addForm.productId,
      storeId: storeId!,
      price,
      stockStatus: addForm.stockStatus,
      stockQty: isNaN(stockQty) ? 0 : stockQty,
      mandatoryFees: [{ label: 'GST (18%)', amount: Math.round(price * 0.18) }],
      discounts: [],
      deliveryCharge: addForm.deliveryCharge ? Number(addForm.deliveryCharge) : null,
      configuration: addForm.configuration || 'Standard',
      isAvailable: true,
      notes: addForm.notes,
    });
    setToast({ msg: 'New listing added.', type: 'success' });
    setShowAddForm(false);
    setAddForm({ productId: '', price: '', stockQty: '', stockStatus: 'in_stock', configuration: '', notes: '', deliveryCharge: '' });
    load();
  };

  const handleReservationStatus = (id: string, status: Reservation['status']) => {
    updateReservationStatus(id, status);
    setToast({ msg: `Reservation ${status}.`, type: 'success' });
    load();
  };

  const STOCK_STATUSES: StoreListing['stockStatus'][] = ['in_stock', 'low_stock', 'out_of_stock', 'display_only'];

  return (
    <div className="page-wrapper">
      <div className="container">
        {/* Header */}
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <span className="badge badge-indigo">RETAILER PORTAL</span>
            <span className="badge badge-amber">DEMO</span>
          </div>
          <h1 style={{ margin: '0 0 0.25rem' }}>{store?.name || 'Retailer Dashboard'}</h1>
          <p style={{ color: 'var(--text-secondary)', margin: 0 }}>
            Manage your product listings and incoming reservations · {store?.city}
          </p>
        </div>

        {/* Stats row */}
        <div className="grid-4" style={{ marginBottom: '2rem' }}>
          <div className="stat-card"><div className="stat-value">{listings.length}</div><div className="stat-label">Total Listings</div></div>
          <div className="stat-card"><div className="stat-value">{listings.filter(l => l.isAvailable).length}</div><div className="stat-label">Available</div></div>
          <div className="stat-card"><div className="stat-value">{reservations.length}</div><div className="stat-label">Total Reservations</div></div>
          <div className="stat-card"><div className="stat-value" style={{ color: '#fcd34d' }}>{reservations.filter(r => r.status === 'pending').length}</div><div className="stat-label">Pending Action</div></div>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: '0', marginBottom: '1.5rem', borderBottom: '1px solid var(--border)' }}>
          {[['inventory', 'Inventory'], ['reservations', 'Reservations']].map(([val, label]) => (
            <button
              key={val}
              onClick={() => setActiveTab(val as typeof activeTab)}
              style={{
                padding: '0.75rem 1.25rem', background: 'none', border: 'none', cursor: 'pointer',
                fontSize: '0.9rem', fontWeight: 600, fontFamily: 'inherit',
                color: activeTab === val ? 'var(--emerald)' : 'var(--text-muted)',
                borderBottom: activeTab === val ? '2px solid var(--emerald)' : '2px solid transparent',
                marginBottom: -1,
              }}
            >
              {label}
              {val === 'reservations' && reservations.filter(r => r.status === 'pending').length > 0 && (
                <span style={{ marginLeft: '0.4rem', background: 'var(--accent-amber)', color: '#000', borderRadius: 999, padding: '0 0.4rem', fontSize: '0.7rem', fontWeight: 700 }}>
                  {reservations.filter(r => r.status === 'pending').length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Inventory tab */}
        {activeTab === 'inventory' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '1rem' }}>
              <button className="btn btn-primary" onClick={() => setShowAddForm(s => !s)} style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Plus size={16} /> Add Listing
              </button>
            </div>

            {/* Add form */}
            {showAddForm && (
              <div className="card-elevated" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
                <h3 style={{ margin: '0 0 1rem', fontSize: '1rem' }}>Add New Listing</h3>
                <div className="grid-3">
                  <div className="form-group">
                    <label className="form-label">Product *</label>
                    <select className="form-select" value={addForm.productId} onChange={e => setAddForm(f => ({ ...f, productId: e.target.value }))}>
                      <option value="">Select product…</option>
                      {allProducts.map(p => <option key={p.id} value={p.id}>{p.name} ({p.brand})</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Price (₹) *</label>
                    <input className="form-input" type="number" min={0} placeholder="e.g. 45000" value={addForm.price} onChange={e => setAddForm(f => ({ ...f, price: e.target.value }))} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Stock Qty</label>
                    <input className="form-input" type="number" min={0} placeholder="e.g. 5" value={addForm.stockQty} onChange={e => setAddForm(f => ({ ...f, stockQty: e.target.value }))} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Stock Status</label>
                    <select className="form-select" value={addForm.stockStatus} onChange={e => setAddForm(f => ({ ...f, stockStatus: e.target.value as any }))}>
                      {STOCK_STATUSES.map(s => <option key={s} value={s}>{stockLabel(s)}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Configuration</label>
                    <input className="form-input" type="text" placeholder="e.g. 8GB/256GB" value={addForm.configuration} onChange={e => setAddForm(f => ({ ...f, configuration: e.target.value }))} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Delivery Charge (₹)</label>
                    <input className="form-input" type="number" min={0} placeholder="0 for free, blank for unknown" value={addForm.deliveryCharge} onChange={e => setAddForm(f => ({ ...f, deliveryCharge: e.target.value }))} />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Notes</label>
                  <input className="form-input" type="text" placeholder="Any notes for customers…" value={addForm.notes} onChange={e => setAddForm(f => ({ ...f, notes: e.target.value }))} />
                </div>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button className="btn btn-primary" onClick={handleAdd}><Save size={14} /> Save Listing</button>
                  <button className="btn btn-ghost" onClick={() => setShowAddForm(false)}>Cancel</button>
                </div>
              </div>
            )}

            {/* Listings table */}
            {listings.length === 0 ? (
              <div className="empty-state"><h3>No listings yet</h3><p>Add your first product listing.</p></div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {listings.map(l => (
                  <div key={l.id} className="card" style={{ padding: '1rem 1.25rem' }}>
                    {editingId === l.id ? (
                      <div>
                        <div className="grid-3" style={{ marginBottom: '0.75rem' }}>
                          <div className="form-group" style={{ margin: 0 }}>
                            <label className="form-label">Price (₹)</label>
                            <input className="form-input" type="number" value={editForm.price} onChange={e => setEditForm(f => ({ ...f, price: Number(e.target.value) }))} />
                          </div>
                          <div className="form-group" style={{ margin: 0 }}>
                            <label className="form-label">Stock Qty</label>
                            <input className="form-input" type="number" value={editForm.stockQty} onChange={e => setEditForm(f => ({ ...f, stockQty: Number(e.target.value) }))} />
                          </div>
                          <div className="form-group" style={{ margin: 0 }}>
                            <label className="form-label">Stock Status</label>
                            <select className="form-select" value={editForm.stockStatus} onChange={e => setEditForm(f => ({ ...f, stockStatus: e.target.value as any }))}>
                              {STOCK_STATUSES.map(s => <option key={s} value={s}>{stockLabel(s)}</option>)}
                            </select>
                          </div>
                          <div className="form-group" style={{ margin: 0 }}>
                            <label className="form-label">Configuration</label>
                            <input className="form-input" type="text" value={editForm.configuration} onChange={e => setEditForm(f => ({ ...f, configuration: e.target.value }))} />
                          </div>
                          <div className="form-group" style={{ margin: 0 }}>
                            <label className="form-label">Available?</label>
                            <select className="form-select" value={editForm.isAvailable ? 'yes' : 'no'} onChange={e => setEditForm(f => ({ ...f, isAvailable: e.target.value === 'yes' }))}>
                              <option value="yes">Yes</option><option value="no">No</option>
                            </select>
                          </div>
                          <div className="form-group" style={{ margin: 0 }}>
                            <label className="form-label">Notes</label>
                            <input className="form-input" type="text" value={editForm.notes} onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))} />
                          </div>
                        </div>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                          <button className="btn btn-primary btn-sm" onClick={saveEdit}><Check size={13} /> Save</button>
                          <button className="btn btn-ghost btn-sm" onClick={() => setEditingId(null)}><X size={13} /> Cancel</button>
                        </div>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.75rem' }}>
                        <div style={{ flex: 1, minWidth: 200 }}>
                          <div style={{ fontWeight: 700 }}>{l.product?.name || l.productId}</div>
                          <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{l.configuration}</div>
                          {l.notes && <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>{l.notes}</div>}
                        </div>
                        <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
                          <div className="price-tag-sm">{formatINR(l.price)}</div>
                          <span className="badge" style={{ background: `${stockColor(l.stockStatus)}22`, color: stockColor(l.stockStatus) }}>{stockLabel(l.stockStatus)}</span>
                          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Qty: {l.stockQty}</span>
                          {!l.isAvailable && <span className="badge badge-gray">Hidden</span>}
                          <Link to={`/products/${l.productId}`} className="btn btn-ghost btn-sm"><Eye size={13} /></Link>
                          <button className="btn btn-secondary btn-sm" onClick={() => startEdit(l)}><Edit2 size={13} /></button>
                          <button className="btn btn-ghost btn-sm" onClick={() => handleDelete(l.id)} style={{ color: 'var(--accent-red)' }}><Trash2 size={13} /></button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Reservations tab */}
        {activeTab === 'reservations' && (
          <div>
            {reservations.length === 0 ? (
              <div className="empty-state"><h3>No reservations</h3><p>Incoming customer reservations will appear here.</p></div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {reservations.map(r => (
                  <div key={r.id} className="card" style={{ padding: '1.25rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '0.75rem', marginBottom: '0.75rem' }}>
                      <div>
                        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.35rem', alignItems: 'center', flexWrap: 'wrap' }}>
                          <ReservationStatusBadge status={r.status} />
                          <span style={{ fontFamily: 'monospace', fontSize: '0.78rem', color: 'var(--text-muted)' }}>{r.referenceNumber}</span>
                        </div>
                        <div style={{ fontWeight: 700 }}>{r.product?.name || r.productId}</div>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{r.configuration}</div>
                      </div>
                      {r.status === 'pending' && (
                        <div style={{ display: 'flex', gap: '0.4rem' }}>
                          <button className="btn btn-primary btn-sm" onClick={() => handleReservationStatus(r.id, 'confirmed')}>
                            <Check size={13} /> Confirm
                          </button>
                          <button className="btn btn-danger btn-sm" onClick={() => handleReservationStatus(r.id, 'rejected')}>
                            <X size={13} /> Reject
                          </button>
                        </div>
                      )}
                      {r.status === 'confirmed' && (
                        <button className="btn btn-secondary btn-sm" onClick={() => handleReservationStatus(r.id, 'completed')}>
                          <Check size={13} /> Mark Completed
                        </button>
                      )}
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '0.5rem', fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                      <div><span style={{ color: 'var(--text-muted)' }}>Customer:</span><br />{r.customerName}</div>
                      <div><span style={{ color: 'var(--text-muted)' }}>Phone:</span><br />{r.customerPhone}</div>
                      <div><span style={{ color: 'var(--text-muted)' }}>Visit:</span><br />{r.visitDate} {r.visitTime}</div>
                      <div><span style={{ color: 'var(--text-muted)' }}>Created:</span><br />{formatDateTime(r.createdAt)}</div>
                    </div>
                    {r.notes && <div style={{ marginTop: '0.5rem', fontSize: '0.78rem', color: 'var(--text-secondary)', background: 'var(--bg)', padding: '0.4rem 0.6rem', borderRadius: 6, border: '1px solid var(--border)' }}>Note: {r.notes}</div>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      </div>
    </div>
  );
}
