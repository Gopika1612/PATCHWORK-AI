// ─────────────────────────────────────────────────────────────────
// Unit tests for TrueCost Intelligence & helpers
// Run with: npx tsx src/tests/trueCost.test.ts  (or jest / vitest)
// ─────────────────────────────────────────────────────────────────

import { calculateTrueCost, calculateEMI } from '../utils/trueCost';
import type { StoreListing } from '../types';

// ── Test harness ──────────────────────────────────────────────────
let passed = 0;
let failed = 0;

function assert(condition: boolean, message: string) {
  if (condition) {
    console.log(`  ✅ PASS: ${message}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${message}`);
    failed++;
  }
}

function assertThrows(fn: () => unknown, message: string) {
  try {
    fn();
    console.error(`  ❌ FAIL (expected throw): ${message}`);
    failed++;
  } catch {
    console.log(`  ✅ PASS (threw as expected): ${message}`);
    passed++;
  }
}

// ── Sample listing fixture ─────────────────────────────────────────
const baseListing: StoreListing = {
  id: 'test-lst',
  productId: 'prod-001',
  storeId: 'store-001',
  price: 89999,
  stockStatus: 'in_stock',
  stockQty: 4,
  mandatoryFees: [{ label: 'GST (18%)', amount: 16200 }],
  discounts: [{ label: 'Student Discount', amount: 3000, eligibilityNote: 'Valid ID required.' }],
  deliveryCharge: 499,
  configuration: '16GB / 512GB',
  lastUpdated: '2026-10-09T10:30:00+05:30',
  isAvailable: true,
  notes: '',
};

// ── Suite 1: Basic calculation ────────────────────────────────────
console.log('\n📦 Suite 1: Basic TrueCost calculations');

const basic = calculateTrueCost(baseListing, {
  includeDelivery: false,
  discountEligibility: {},
});
assert(basic.listedPrice === 89999, 'Listed price is correct');
assert(basic.mandatoryFees.length === 1, 'Mandatory fee included');
assert(basic.appliedDiscounts.length === 0, 'No discount applied without eligibility');
assert(basic.deliveryCharge === null, 'Delivery not included when not requested');
assert(basic.estimatedTotal === 89999 + 16200, 'Total = price + fees (no discount, no delivery)');

// ── Suite 2: With delivery ────────────────────────────────────────
console.log('\n📦 Suite 2: With delivery');
const withDelivery = calculateTrueCost(baseListing, {
  includeDelivery: true,
  discountEligibility: {},
});
assert(withDelivery.deliveryCharge === 499, 'Delivery charge included');
assert(withDelivery.estimatedTotal === 89999 + 16200 + 499, 'Total includes delivery');

// ── Suite 3: With eligible discount ──────────────────────────────
console.log('\n📦 Suite 3: With eligible discount');
const withDiscount = calculateTrueCost(baseListing, {
  includeDelivery: false,
  discountEligibility: { 'Student Discount': true },
});
assert(withDiscount.appliedDiscounts.length === 1, 'Discount applied');
assert(
  withDiscount.estimatedTotal === 89999 + 16200 - 3000,
  'Total = price + fees - discount'
);

// ── Suite 4: Full calculation ─────────────────────────────────────
console.log('\n📦 Suite 4: Full calculation (delivery + discount)');
const full = calculateTrueCost(baseListing, {
  includeDelivery: true,
  discountEligibility: { 'Student Discount': true },
});
assert(full.estimatedTotal === 89999 + 16200 + 499 - 3000, 'Full calculation correct');

// ── Suite 5: Unknown delivery charge ─────────────────────────────
console.log('\n📦 Suite 5: Unknown delivery charge');
const nullDeliveryListing: StoreListing = { ...baseListing, deliveryCharge: null };
const nullDel = calculateTrueCost(nullDeliveryListing, {
  includeDelivery: true,
  discountEligibility: {},
});
assert(nullDel.deliveryCharge === null, 'Delivery charge null when unknown');
assert(nullDel.missingInfo.length > 0, 'Missing info populated for unknown delivery');

// ── Suite 6: Double-discount prevention ──────────────────────────
console.log('\n📦 Suite 6: Double-discount prevention');
const doubleDiscountListing: StoreListing = {
  ...baseListing,
  discounts: [
    { label: 'Student Discount', amount: 3000, eligibilityNote: '' },
    { label: 'Student Discount', amount: 3000, eligibilityNote: '' }, // duplicate
  ],
};
const double = calculateTrueCost(doubleDiscountListing, {
  includeDelivery: false,
  discountEligibility: { 'Student Discount': true },
});
assert(double.appliedDiscounts.length === 1, 'Duplicate discount applied only once');
assert(double.estimatedTotal === 89999 + 16200 - 3000, 'Double discount not applied twice');

// ── Suite 7: Validation – negative price ─────────────────────────
console.log('\n📦 Suite 7: Input validation');
assertThrows(
  () => calculateTrueCost({ ...baseListing, price: -100 }, { includeDelivery: false, discountEligibility: {} }),
  'Throws on negative price'
);

// ── Suite 8: EMI Calculator ───────────────────────────────────────
console.log('\n📦 Suite 8: EMI calculations');
const emi = calculateEMI(100000, 12, 12);
assert(Math.round(emi.monthlyInstalment) === 8885, 'EMI monthly instalment correct (₹1L @ 12% for 12m)');
assert(emi.totalRepayment > 100000, 'Total repayment > principal (has interest)');
assert(Math.round(emi.totalInterest) > 0, 'Interest is positive');

const zeroInterestEmi = calculateEMI(60000, 0, 6);
assert(zeroInterestEmi.monthlyInstalment === 10000, 'Zero-interest EMI correct');
assert(zeroInterestEmi.totalInterest === 0, 'Zero interest when rate is 0');

assertThrows(
  () => calculateEMI(-1000, 10, 6),
  'Throws on negative principal'
);

// ── Suite 9: Total cannot go below zero ──────────────────────────
console.log('\n📦 Suite 9: Total cannot go negative');
const bigDiscountListing: StoreListing = {
  ...baseListing,
  price: 100,
  mandatoryFees: [],
  discounts: [{ label: 'Huge Discount', amount: 99999, eligibilityNote: '' }],
  deliveryCharge: 0,
};
const bigDiscount = calculateTrueCost(bigDiscountListing, {
  includeDelivery: true,
  discountEligibility: { 'Huge Discount': true },
});
assert(bigDiscount.estimatedTotal >= 0, 'Total is non-negative');

// ── Results ───────────────────────────────────────────────────────
console.log(`\n${'─'.repeat(50)}`);
console.log(`Results: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
