// ─────────────────────────────────────────────
// Core domain types for Hyperlocal Reserve
// ALL DATA IS DEMO / ILLUSTRATIVE
// ─────────────────────────────────────────────

export type Category =
  | 'laptops'
  | 'smartphones'
  | 'tablets'
  | 'monitors'
  | 'accessories'
  | 'gaming';

export interface ProductSpec {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  model: string;
  category: Category;
  imageUrl: string;
  shortDescription: string;
  specs: ProductSpec[];
  tags: string[];
}

export interface StoreCoordinates {
  lat: number;
  lng: number;
}

export interface StoreHours {
  day: string;
  open: string;
  close: string;
}

export interface Store {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone: string; // DEMO – not a real number
  email: string; // DEMO – not a real address
  coordinates: StoreCoordinates;
  hours: StoreHours[];
  description: string;
  logoInitials: string;
  accentColor: string;
}

export type StockStatus = 'in_stock' | 'low_stock' | 'out_of_stock' | 'display_only';

export interface MandatoryFee {
  label: string;
  amount: number; // INR
}

export interface Discount {
  label: string;
  amount: number; // INR
  eligibilityNote: string;
}

export interface StoreListing {
  id: string;
  productId: string;
  storeId: string;
  price: number; // listed price INR
  stockStatus: StockStatus;
  stockQty: number;
  mandatoryFees: MandatoryFee[];
  discounts: Discount[];
  deliveryCharge: number | null; // null = unknown
  configuration: string; // e.g. "16GB RAM / 512GB SSD"
  lastUpdated: string; // ISO timestamp
  isAvailable: boolean;
  notes: string;
}

export type ReservationStatus =
  | 'pending'
  | 'confirmed'
  | 'rejected'
  | 'cancelled'
  | 'completed';

export interface Reservation {
  id: string;
  referenceNumber: string;
  listingId: string;
  productId: string;
  storeId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  visitDate: string; // YYYY-MM-DD
  visitTime: string; // HH:MM
  status: ReservationStatus;
  createdAt: string; // ISO
  updatedAt: string; // ISO
  notes: string;
  configuration: string;
}

// ─── Cost Calculation ─────────────────────────
export interface CostBreakdown {
  listedPrice: number;
  mandatoryFees: MandatoryFee[];
  appliedDiscounts: Discount[];
  deliveryCharge: number | null;
  estimatedTotal: number;
  missingInfo: string[];
  lastUpdated: string;
}

// ─── UI / filter state ────────────────────────
export interface SearchFilters {
  query: string;
  category: Category | '';
  brand: string;
  minPrice: number | '';
  maxPrice: number | '';
  stockStatus: StockStatus | '';
  sortBy: 'price_asc' | 'price_desc' | 'distance' | 'relevance';
}

export interface UserLocation {
  lat: number;
  lng: number;
  granted: boolean;
}

// ─── Retailer / Auth (demo only) ──────────────
export type DemoRole = 'customer' | 'retailer' | 'admin';

export interface DemoUser {
  role: DemoRole;
  storeId?: string; // for retailer role
  name: string;
}
