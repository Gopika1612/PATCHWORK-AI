// ─────────────────────────────────────────────
// Utility: Haversine distance calculator
// ─────────────────────────────────────────────
export function haversineDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km.toFixed(1)} km`;
}

// ─────────────────────────────────────────────
// Utility: Currency formatter (INR)
// ─────────────────────────────────────────────
export const formatINR = (amount: number): string =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);

// ─────────────────────────────────────────────
// Utility: Date / time helpers
// ─────────────────────────────────────────────
export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function generateReferenceNumber(): string {
  const now = new Date();
  const date = now.toISOString().slice(0, 10).replace(/-/g, '');
  const rand = Math.floor(Math.random() * 9000 + 1000);
  return `HLR-${date}-${rand}`;
}

export function generateId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

// ─────────────────────────────────────────────
// Utility: Stock label helpers
// ─────────────────────────────────────────────
export function stockLabel(status: string): string {
  switch (status) {
    case 'in_stock': return 'In Stock';
    case 'low_stock': return 'Low Stock';
    case 'out_of_stock': return 'Out of Stock';
    case 'display_only': return 'Display Only';
    default: return 'Unknown';
  }
}

export function stockColor(status: string): string {
  switch (status) {
    case 'in_stock': return '#10b981';
    case 'low_stock': return '#f59e0b';
    case 'out_of_stock': return '#ef4444';
    case 'display_only': return '#6366f1';
    default: return '#6b7280';
  }
}

export function reservationStatusLabel(status: string): string {
  switch (status) {
    case 'pending': return 'Pending';
    case 'confirmed': return 'Confirmed';
    case 'rejected': return 'Rejected';
    case 'cancelled': return 'Cancelled';
    case 'completed': return 'Completed';
    default: return 'Unknown';
  }
}

export function reservationStatusColor(status: string): string {
  switch (status) {
    case 'pending': return '#f59e0b';
    case 'confirmed': return '#10b981';
    case 'rejected': return '#ef4444';
    case 'cancelled': return '#6b7280';
    case 'completed': return '#6366f1';
    default: return '#6b7280';
  }
}

// ─────────────────────────────────────────────
// Utility: Maps link generator
// ─────────────────────────────────────────────
export function mapsLink(lat: number, lng: number, address: string): string {
  const query = encodeURIComponent(`${address}`);
  return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}&query_place_id=${query}`;
}

export function mapsLinkFromAddress(address: string): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
}
