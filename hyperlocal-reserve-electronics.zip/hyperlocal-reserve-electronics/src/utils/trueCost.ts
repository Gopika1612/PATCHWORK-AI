// ─────────────────────────────────────────────────────────────────
// TrueCost Intelligence — Local cost calculation engine
// Formula: Estimated Total = Listed Price
//          + Applicable Mandatory Fees
//          + Optional Delivery Charge (if selected)
//          − Eligible Discounts
//
// Rules:
//  • Prices and fees must be non-negative.
//  • Discounts applied at most once each.
//  • Unknown delivery treated as "Not provided" — never silently zero.
//  • EMI is a separate concern — not mixed with outright price.
// ─────────────────────────────────────────────────────────────────

import type { StoreListing, CostBreakdown, MandatoryFee, Discount } from '../types';

export interface TrueCostOptions {
  /** True if the user has chosen to include delivery */
  includeDelivery: boolean;
  /**
   * For each discount id/label, whether the customer has confirmed eligibility.
   * Key = discount label, value = true/false
   */
  discountEligibility: Record<string, boolean>;
}

export function calculateTrueCost(
  listing: StoreListing,
  options: TrueCostOptions
): CostBreakdown {
  const missingInfo: string[] = [];

  // Validate listed price
  if (!isFinite(listing.price) || listing.price < 0) {
    throw new Error('Listed price must be a non-negative finite number.');
  }

  // Mandatory fees — validate each
  const validFees: MandatoryFee[] = [];
  for (const fee of listing.mandatoryFees) {
    if (!isFinite(fee.amount) || fee.amount < 0) {
      missingInfo.push(`Fee "${fee.label}" has an invalid amount and was excluded.`);
    } else {
      validFees.push(fee);
    }
  }

  // Discounts — apply only when eligibility confirmed, avoid double-apply
  const appliedDiscounts: Discount[] = [];
  const seenLabels = new Set<string>();
  for (const discount of listing.discounts) {
    if (seenLabels.has(discount.label)) continue; // prevent double-apply
    seenLabels.add(discount.label);

    const eligible = options.discountEligibility[discount.label] ?? false;
    if (eligible) {
      if (!isFinite(discount.amount) || discount.amount < 0) {
        missingInfo.push(`Discount "${discount.label}" has an invalid amount and was not applied.`);
      } else {
        appliedDiscounts.push(discount);
      }
    }
  }

  // Delivery charge
  let deliveryCharge: number | null = null;
  if (options.includeDelivery) {
    if (listing.deliveryCharge === null) {
      missingInfo.push('Delivery charge: Not provided by store — contact store for delivery pricing.');
    } else if (listing.deliveryCharge < 0) {
      missingInfo.push('Delivery charge has an invalid value.');
    } else {
      deliveryCharge = listing.deliveryCharge;
    }
  }

  const totalFees = validFees.reduce((s, f) => s + f.amount, 0);
  const totalDiscounts = appliedDiscounts.reduce((s, d) => s + d.amount, 0);
  const deliveryAmount = deliveryCharge ?? 0;

  const estimatedTotal =
    listing.price + totalFees + deliveryAmount - totalDiscounts;

  return {
    listedPrice: listing.price,
    mandatoryFees: validFees,
    appliedDiscounts,
    deliveryCharge: deliveryCharge,
    estimatedTotal: Math.max(0, estimatedTotal), // cannot go below 0
    missingInfo,
    lastUpdated: listing.lastUpdated,
  };
}

// ── EMI calculator (separate — not mixed with outright cost) ──────
export interface EMIResult {
  monthlyInstalment: number;
  totalRepayment: number;
  totalInterest: number;
  months: number;
  annualRate: number;
}

export function calculateEMI(
  principal: number,
  annualRatePercent: number,
  months: number
): EMIResult {
  if (principal <= 0 || months <= 0) {
    throw new Error('Principal and months must be positive.');
  }
  if (annualRatePercent < 0) {
    throw new Error('Annual rate cannot be negative.');
  }
  if (annualRatePercent === 0) {
    const monthly = principal / months;
    return {
      monthlyInstalment: monthly,
      totalRepayment: principal,
      totalInterest: 0,
      months,
      annualRate: 0,
    };
  }
  const r = annualRatePercent / 100 / 12;
  const emi = (principal * r * (1 + r) ** months) / ((1 + r) ** months - 1);
  const totalRepayment = emi * months;
  return {
    monthlyInstalment: emi,
    totalRepayment,
    totalInterest: totalRepayment - principal,
    months,
    annualRate: annualRatePercent,
  };
}
