import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Home, Search, Store, BookOpen, Zap, MapPin, SlidersHorizontal,
  X, ArrowRight, Calendar, Clock, User, Phone, Mail,
  Package, CheckCircle, XCircle, RefreshCw, ChevronDown,
  Laptop, Smartphone, Monitor, Headphones, Gamepad2,
  TrendingUp, Shield, AlertCircle, ExternalLink, Tag
} from 'lucide-react';
import {
  getProducts, getStores, getListings, getReservations,
  getProductById, getStoreById, getListingById,
  searchProducts, ensureSeeded, createReservation,
  updateReservationStatus, getListingsForProduct, getListingsForStore
} from '../services/dataService';
import { calculateTrueCost } from '../utils/trueCost';
import {
  formatINR, stockLabel, stockColor, formatDate, formatDateTime,
  mapsLink, generateId
} from '../utils/helpers';
import type {
  Product, Store as StoreType, StoreListing, Reservation,
  SearchFilters, Category, UserLocation
} from '../types';
import { ReservationStatusBadge, Toast } from './Shared';

// ─── Tab IDs ──────────────────────────────────────────────────────
type Tab = 'home' | 'browse' | 'stores' | 'reservations';

// ─── Helper: Product image with fallback ─────────────────────────
function ProductImg({ src, alt }: { src: string; alt: string }) {
  const [err, setErr] = useState(false);
  if (err) return (
    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-elevated)', color: 'var(--text-muted)', flexDirection: 'column', gap: 4 }}>
      <Package size={28} style={{ opacity: 0.4 }} /><span style={{ fontSize: '0.7rem' }}>{alt}</span>
    </div>
  );
  return <img src={src} alt={alt} onError={() => setErr(true)} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />;
}

const CATEGORIES: { id: Category; label: string; icon: React.ReactNode; color: string }[] = [
  { id: 'laptops', label: 'Laptops', icon: <Laptop size={20} />, color: '#10b981' },
  { id: 'smartphones', label: 'Smartphones', icon: <Smartphone size={20} />, color: '#6366f1' },
  { id: 'monitors', label: 'Monitors', icon: <Monitor size={20} />, color: '#f59e0b' },
  { id: 'tablets', label: 'Tablets', icon: <Package size={20} />, color: '#8b5cf6' },
  { id: 'accessories', label: 'Accessories', icon: <Headphones size={20} />, color: '#ef4444' },
  { id: 'gaming', label: 'Gaming', icon: <Gamepad2 size={20} />, color: '#ec4899' },
];

const TIME_SLOTS = [
  '10:00','10:30','11:00','11:30','12:00','12:30',
  '13:00','13:30','14:00','14:30','15:00','15:30',
  '16:00','16:30','17:00','17:30','18:00','18:30','19:00',
];

function getMinDate() { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); }
function getMaxDate() { const d = new Date(); d.setDate(d.getDate() + 30); return d.toISOString().slice(0, 10); }
function validateEmail(e: string) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }
function validatePhone(p: string) { return /^[+]?[\d\s\-()]{7,15}$/.test(p); }

// ─── Main Customer Portal ─────────────────────────────────────────
export default function CustomerPortal() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<Tab>((searchParams.get('tab') as Tab) || 'home');
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);

  // ── Home state
  const [heroQuery, setHeroQuery] = useState('');
  const [homeProducts, setHomeProducts] = useState<(Product & { minPrice: number; storeCount: number })[]>([]);
  const [homeStores, setHomeStores] = useState<(StoreType & { listingCount: number })[]>([]);

  // ── Browse state
  const [filters, setFilters] = useState<SearchFilters>({ query: '', category: '', brand: '', minPrice: '', maxPrice: '', stockStatus: '', sortBy: 'relevance' });
  const [browseResults, setBrowseResults] = useState<ReturnType<typeof searchProducts>>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [location, setLocation] = useState<UserLocation | null>(null);

  // ── Product/Store detail overlay
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedStore, setSelectedStore] = useState<StoreType | null>(null);
  const [productListings, setProductListings] = useState<(StoreListing & { store: StoreType })[]>([]);
  const [storeListings, setStoreListings] = useState<(StoreListing & { product: Product })[]>([]);

  // ── TrueCost
  const [selectedListingId, setSelectedListingId] = useState<string | null>(null);
  const [includeDelivery, setIncludeDelivery] = useState(false);
  const [discountElig, setDiscountElig] = useState<Record<string, boolean>>({});

  // ── Reservation modal
  const [reserveListingId, setReserveListingId] = useState<string | null>(null);
  const [resStep, setResStep] = useState<1 | 2 | 3 | 4>(1);
  const [resForm, setResForm] = useState({ name: '', phone: '', email: '', visitDate: '', visitTime: '', notes: '' });
  const [resErrors, setResErrors] = useState<Record<string, string>>({});
  const [resConfirmedRef, setResConfirmedRef] = useState<string | null>(null);
  const [resSubmitting, setResSubmitting] = useState(false);

  // ── My Reservations
  const [myReservations, setMyReservations] = useState<(Reservation & { product?: Product; store?: StoreType })[]>([]);
  const [resFilter, setResFilter] = useState('all');
  const [confirmCancel, setConfirmCancel] = useState<string | null>(null);

  // ── Stores
  const [allStores, setAllStores] = useState<(StoreType & { listingCount: number })[]>([]);
  const [storeQuery, setStoreQuery] = useState('');

  useEffect(() => {
    ensureSeeded();
    loadHomeData();
    loadReservations();
    loadStores();
  }, []);

  useEffect(() => {
    const res = searchProducts(filters, location);
    setBrowseResults(res);
  }, [filters, location]);

  useEffect(() => {
    const tab = searchParams.get('tab') as Tab;
    if (tab) setActiveTab(tab);
  }, [searchParams]);

  const switchTab = (tab: Tab) => {
    setActiveTab(tab);
    setSearchParams({ tab });
    setSelectedProduct(null);
    setSelectedStore(null);
  };

  function loadHomeData() {
    const ps = getProducts();
    const ls = getListings();
    const ss = getStores();
    setHomeProducts(ps.slice(0, 6).map(p => {
      const pls = ls.filter(l => l.productId === p.id && l.isAvailable);
      return { ...p, minPrice: pls.length ? Math.min(...pls.map(l => l.price)) : 0, storeCount: new Set(pls.map(l => l.storeId)).size };
    }));
    setHomeStores(ss.map(s => ({ ...s, listingCount: ls.filter(l => l.storeId === s.id && l.isAvailable).length })));
    const res = searchProducts({ query: '', category: '', brand: '', minPrice: '', maxPrice: '', stockStatus: '', sortBy: 'relevance' });
    setBrowseResults(res);
  }

  function loadReservations() {
    const rs = getReservations().map(r => ({ ...r, product: getProductById(r.productId), store: getStoreById(r.storeId) }));
    rs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    setMyReservations(rs);
  }

  function loadStores() {
    const ls = getListings();
    setAllStores(getStores().map(s => ({ ...s, listingCount: ls.filter(l => l.storeId === s.id && l.isAvailable).length })));
  }

  function openProduct(product: Product) {
    setSelectedProduct(product);
    setSelectedStore(null);
    const ls = getListingsForProduct(product.id)
      .map(l => { const store = getStoreById(l.storeId); return store ? { ...l, store } : null; })
      .filter(Boolean) as (StoreListing & { store: StoreType })[];
    ls.sort((a, b) => a.price - b.price);
    setProductListings(ls);
    setSelectedListingId(ls[0]?.id || null);
    setIncludeDelivery(false);
    setDiscountElig({});
  }

  function openStore(store: StoreType) {
    setSelectedStore(store);
    setSelectedProduct(null);
    const ls = getListingsForStore(store.id)
      .map(l => { const product = getProductById(l.productId); return product ? { ...l, product } : null; })
      .filter(Boolean) as (StoreListing & { product: Product })[];
    setStoreListings(ls);
  }

  function startReserve(listingId: string) {
    setReserveListingId(listingId);
    setResStep(1);
    setResForm({ name: '', phone: '', email: '', visitDate: '', visitTime: '', notes: '' });
    setResErrors({});
    setResConfirmedRef(null);
  }

  function validateResStep1() {
    const e: Record<string, string> = {};
    if (!resForm.name.trim() || resForm.name.trim().length < 2) e.name = 'Full name required (min 2 chars)';
    if (!validatePhone(resForm.phone)) e.phone = 'Valid phone required';
    if (!validateEmail(resForm.email)) e.email = 'Valid email required';
    setResErrors(e);
    return Object.keys(e).length === 0;
  }

  function validateResStep2() {
    const e: Record<string, string> = {};
    if (!resForm.visitDate) e.visitDate = 'Select a date';
    if (!resForm.visitTime) e.visitTime = 'Select a time slot';
    setResErrors(e);
    return Object.keys(e).length === 0;
  }

  async function submitReservation() {
    if (!reserveListingId) return;
    const listing = getListingById(reserveListingId);
    if (!listing) return;
    setResSubmitting(true);
    try {
      const res = createReservation({
        listingId: listing.id, productId: listing.productId, storeId: listing.storeId,
        customerName: resForm.name.trim(), customerPhone: resForm.phone.trim(),
        customerEmail: resForm.email.trim(), visitDate: resForm.visitDate,
        visitTime: resForm.visitTime, notes: resForm.notes.trim(), configuration: listing.configuration,
      });
      setResConfirmedRef(res.referenceNumber);
      setResStep(4);
      loadReservations();
    } catch {
      setToast({ msg: 'Failed to submit reservation.', type: 'error' });
    } finally {
      setResSubmitting(false);
    }
  }

  function cancelReservation(id: string) {
    updateReservationStatus(id, 'cancelled');
    setToast({ msg: 'Reservation cancelled.', type: 'success' });
    setConfirmCancel(null);
    loadReservations();
  }

  const requestLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      pos => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude, granted: true }),
      () => setLocation({ lat: 0, lng: 0, granted: false })
    );
  };

  // ── Selected listing for TrueCost
  const selListing = productListings.find(l => l.id === selectedListingId);
  const trueCost = selListing ? calculateTrueCost(selListing, { includeDelivery, discountEligibility: discountElig }) : null;

  // ── Reserve listing data
  const resListing = reserveListingId ? getListingById(reserveListingId) : null;
  const resProduct = resListing ? getProductById(resListing.productId) : null;
  const resStore = resListing ? getStoreById(resListing.storeId) : null;

  const filteredReservations = resFilter === 'all' ? myReservations : myReservations.filter(r => r.status === resFilter);
  const filteredStores = allStores.filter(s => !storeQuery || s.name.toLowerCase().includes(storeQuery.toLowerCase()) || s.city.toLowerCase().includes(storeQuery.toLowerCase()));

  // ─── TABS BAR ─────────────────────────────────────────────────────
  const TABS = [
    { id: 'home' as Tab, label: 'Home', icon: <Home size={16} /> },
    { id: 'browse' as Tab, label: 'Browse', icon: <Search size={16} /> },
    { id: 'stores' as Tab, label: 'Stores', icon: <Store size={16} /> },
    { id: 'reservations' as Tab, label: 'My Reservations', icon: <BookOpen size={16} /> },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      {/* ── Top tab bar ─────────────────────────────────────────── */}
      <div style={{ background: 'var(--bg-card)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 50 }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', height: 52 }}>
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginRight: '1rem', flexShrink: 0 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: 'linear-gradient(135deg,#10b981,#059669)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Zap size={15} color="#fff" fill="#fff" />
            </div>
            <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 800, fontSize: '0.9rem' }}>
              Hyperlocal<span style={{ color: 'var(--emerald)' }}>Reserve</span>
            </span>
          </div>

          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => switchTab(t.id)}
              id={`tab-${t.id}`}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.35rem',
                padding: '0.35rem 0.875rem', borderRadius: 8,
                background: activeTab === t.id ? 'rgba(16,185,129,0.12)' : 'transparent',
                color: activeTab === t.id ? 'var(--emerald)' : 'var(--text-secondary)',
                border: activeTab === t.id ? '1px solid rgba(16,185,129,0.3)' : '1px solid transparent',
                fontWeight: activeTab === t.id ? 600 : 400,
                fontSize: '0.85rem', cursor: 'pointer', fontFamily: 'inherit',
                transition: 'all 0.15s', flexShrink: 0,
                position: 'relative',
              }}
            >
              {t.icon} {t.label}
              {t.id === 'reservations' && myReservations.filter(r => r.status === 'pending').length > 0 && (
                <span style={{ position: 'absolute', top: 2, right: 2, width: 7, height: 7, borderRadius: '50%', background: 'var(--accent-amber)' }} />
              )}
            </button>
          ))}

          <div style={{ marginLeft: 'auto', fontSize: '0.72rem', color: '#fcd34d', display: 'flex', alignItems: 'center', gap: '0.3rem', flexShrink: 0 }}>
            ⚡ DEMO MODE
          </div>
        </div>
      </div>

      {/* ══════════════════ HOME TAB ══════════════════════════════ */}
      {activeTab === 'home' && !selectedProduct && !selectedStore && (
        <div>
          {/* Hero */}
          <div className="hero-gradient" style={{ padding: '3.5rem 0 2.5rem', textAlign: 'center' }}>
            <div className="container">
              <h1 style={{ fontSize: 'clamp(1.75rem,4vw,3rem)', fontWeight: 900, margin: '0 0 0.75rem', lineHeight: 1.15 }}>
                Find it nearby.<br />
                <span style={{ background: 'linear-gradient(135deg,var(--emerald),var(--emerald-light))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                  Compare smartly. Inspect first.
                </span>
              </h1>
              <p style={{ color: 'var(--text-secondary)', margin: '0 0 2rem', fontSize: '1rem', maxWidth: 480, marginLeft: 'auto', marginRight: 'auto' }}>
                Discover electronics nearby, see the TrueCost™ breakdown, and reserve for in-store inspection.
              </p>
              <form onSubmit={e => { e.preventDefault(); setFilters(f => ({ ...f, query: heroQuery })); switchTab('browse'); }}
                style={{ display: 'flex', gap: '0.5rem', maxWidth: 520, margin: '0 auto', flexWrap: 'wrap' }}>
                <div style={{ flex: 1, minWidth: 200, position: 'relative' }}>
                  <Search size={16} style={{ position: 'absolute', left: '0.875rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                  <input className="form-input" type="text" placeholder="Search laptops, phones…"
                    value={heroQuery} onChange={e => setHeroQuery(e.target.value)}
                    style={{ paddingLeft: '2.5rem', height: 48 }} id="customer-hero-search" />
                </div>
                <button type="submit" className="btn btn-primary" style={{ height: 48, gap: '0.3rem' }}>
                  Search <ArrowRight size={16} />
                </button>
              </form>

              {/* Stats */}
              <div style={{ display: 'flex', justifyContent: 'center', gap: '2rem', marginTop: '2rem', flexWrap: 'wrap' }}>
                {[['8', 'Products'], ['5', 'Stores'], ['20+', 'Listings'], ['Free', 'Demo']].map(([v, l]) => (
                  <div key={l} style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '1.3rem', fontWeight: 800, color: 'var(--emerald)' }}>{v}</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Category shortcuts */}
          <div style={{ background: 'var(--bg-card)', padding: '2rem 0' }}>
            <div className="container">
              <h2 style={{ margin: '0 0 1rem', fontSize: '1.1rem' }}>Browse by Category</h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(110px, 1fr))', gap: '0.75rem' }}>
                {CATEGORIES.map(c => (
                  <button key={c.id} onClick={() => { setFilters(f => ({ ...f, category: c.id })); switchTab('browse'); }}
                    style={{ padding: '1rem 0.5rem', textAlign: 'center', background: `${c.color}11`, border: `1px solid ${c.color}22`,
                      borderRadius: 'var(--radius)', cursor: 'pointer', color: c.color, fontFamily: 'inherit', transition: 'all 0.15s' }}
                    id={`cat-${c.id}`}>
                    <div style={{ marginBottom: '0.4rem', display: 'flex', justifyContent: 'center' }}>{c.icon}</div>
                    <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-primary)' }}>{c.label}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Featured products */}
          <div style={{ padding: '2rem 0' }}>
            <div className="container">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h2 style={{ margin: 0, fontSize: '1.1rem' }}>Featured Electronics <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 400 }}>· DEMO DATA</span></h2>
                <button onClick={() => switchTab('browse')} className="btn btn-ghost btn-sm">View all →</button>
              </div>
              <div className="grid-3">
                {homeProducts.map(p => (
                  <button key={p.id} onClick={() => { openProduct(p); switchTab('browse'); }}
                    style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', textAlign: 'left' }}>
                    <div className="card" style={{ height: '100%', overflow: 'hidden' }}>
                      <div style={{ height: 160, overflow: 'hidden', background: 'var(--bg-elevated)' }}>
                        <ProductImg src={p.imageUrl} alt={p.name} />
                      </div>
                      <div style={{ padding: '0.875rem' }}>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{p.brand} · {p.model}</div>
                        <div style={{ fontWeight: 700, fontSize: '0.95rem', margin: '0.2rem 0' }}>{p.name}</div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span className="price-tag-sm">{p.minPrice > 0 ? formatINR(p.minPrice) : '—'}</span>
                          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{p.storeCount} store{p.storeCount !== 1 ? 's' : ''}</span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* How it works */}
          <div style={{ background: 'var(--bg-card)', padding: '2rem 0' }}>
            <div className="container">
              <h2 style={{ margin: '0 0 1.25rem', fontSize: '1.1rem', textAlign: 'center' }}>How It Works</h2>
              <div className="grid-4">
                {[
                  { icon: <Search size={20} />, step: '01', title: 'Search Products', desc: 'Find by name, brand, or model.' },
                  { icon: <TrendingUp size={20} />, step: '02', title: 'Compare Prices', desc: 'See all nearby stores with full fee breakdown.' },
                  { icon: <Shield size={20} />, step: '03', title: 'TrueCost™', desc: 'Know the real total before you visit.' },
                  { icon: <Clock size={20} />, step: '04', title: 'Reserve', desc: 'Book a slot to inspect — no payment needed.' },
                ].map((s, i) => (
                  <div key={i} className="card" style={{ padding: '1.25rem' }}>
                    <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(16,185,129,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--emerald)', marginBottom: '0.75rem' }}>
                      {s.icon}
                    </div>
                    <div style={{ fontSize: '0.65rem', fontWeight: 800, color: 'var(--text-muted)', letterSpacing: '0.1em', marginBottom: '0.25rem' }}>STEP {s.step}</div>
                    <div style={{ fontWeight: 700, fontSize: '0.9rem', marginBottom: '0.3rem' }}>{s.title}</div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{s.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════ BROWSE TAB ════════════════════════════ */}
      {activeTab === 'browse' && !selectedProduct && (
        <div style={{ padding: '1.5rem 0 3rem' }}>
          <div className="container">
            {/* Search row */}
            <div style={{ display: 'flex', gap: '0.6rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <div style={{ flex: 1, minWidth: 200, position: 'relative' }}>
                <Search size={16} style={{ position: 'absolute', left: '0.875rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                <input className="form-input" type="text" placeholder="Search products…"
                  value={filters.query} onChange={e => setFilters(f => ({ ...f, query: e.target.value }))}
                  style={{ paddingLeft: '2.5rem' }} id="browse-search" />
              </div>
              <select className="form-select" value={filters.sortBy} onChange={e => setFilters(f => ({ ...f, sortBy: e.target.value as any }))} style={{ width: 'auto', minWidth: 160 }}>
                <option value="relevance">Relevance</option>
                <option value="price_asc">Price ↑</option>
                <option value="price_desc">Price ↓</option>
                <option value="distance">Distance</option>
              </select>
              <button className={`btn ${showFilters ? 'btn-primary' : 'btn-secondary'} btn-sm`} onClick={() => setShowFilters(f => !f)}>
                <SlidersHorizontal size={14} /> Filters
              </button>
              <button className="btn btn-secondary btn-sm" onClick={requestLocation} style={{ display: 'flex', gap: '0.3rem' }}>
                <MapPin size={14} style={{ color: location?.granted ? 'var(--emerald)' : undefined }} />
                {location?.granted ? 'Near me ✓' : 'Near me'}
              </button>
            </div>

            {/* Category pills */}
            <div style={{ display: 'flex', gap: '0.4rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              {[{ id: '', label: 'All' }, ...CATEGORIES.map(c => ({ id: c.id, label: c.label }))].map(c => (
                <button key={c.id} onClick={() => setFilters(f => ({ ...f, category: c.id as any }))}
                  style={{
                    padding: '0.25rem 0.75rem', borderRadius: 999, fontSize: '0.78rem', fontWeight: 500,
                    border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                    background: filters.category === c.id ? 'rgba(16,185,129,0.2)' : 'var(--bg-elevated)',
                    color: filters.category === c.id ? 'var(--emerald)' : 'var(--text-secondary)',
                    outline: filters.category === c.id ? '1px solid var(--emerald)' : '1px solid var(--border)',
                  }} id={`filter-cat-${c.id || 'all'}`}>
                  {c.label}
                </button>
              ))}
            </div>

            {/* Advanced filters */}
            {showFilters && (
              <div className="card-elevated" style={{ padding: '1rem', marginBottom: '1rem' }}>
                <div className="grid-4">
                  <div className="form-group" style={{ margin: 0 }}>
                    <label className="form-label">Brand</label>
                    <input className="form-input" placeholder="e.g. NovaTech" value={filters.brand} onChange={e => setFilters(f => ({ ...f, brand: e.target.value }))} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label className="form-label">Min Price ₹</label>
                    <input className="form-input" type="number" placeholder="0" value={filters.minPrice} onChange={e => setFilters(f => ({ ...f, minPrice: e.target.value === '' ? '' : Number(e.target.value) }))} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label className="form-label">Max Price ₹</label>
                    <input className="form-input" type="number" placeholder="200000" value={filters.maxPrice} onChange={e => setFilters(f => ({ ...f, maxPrice: e.target.value === '' ? '' : Number(e.target.value) }))} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label className="form-label">Stock</label>
                    <select className="form-select" value={filters.stockStatus} onChange={e => setFilters(f => ({ ...f, stockStatus: e.target.value as any }))}>
                      <option value="">Any</option><option value="in_stock">In Stock</option>
                      <option value="low_stock">Low Stock</option><option value="out_of_stock">Out of Stock</option>
                    </select>
                  </div>
                </div>
                <button className="btn btn-ghost btn-sm" onClick={() => setFilters({ query: '', category: '', brand: '', minPrice: '', maxPrice: '', stockStatus: '', sortBy: 'relevance' })} style={{ marginTop: '0.5rem' }}>
                  <X size={13} /> Clear filters
                </button>
              </div>
            )}

            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>{browseResults.length} product{browseResults.length !== 1 ? 's' : ''} found</p>

            {browseResults.length === 0 ? (
              <div className="empty-state"><div className="empty-state-icon">🔍</div><h3>No products found</h3><p>Try different filters.</p></div>
            ) : (
              <div className="grid-3">
                {browseResults.map(p => (
                  <button key={p.id} onClick={() => openProduct(p)}
                    style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', textAlign: 'left' }}>
                    <div className="card" style={{ height: '100%', overflow: 'hidden' }} id={`product-card-${p.id}`}>
                      <div style={{ height: 160, overflow: 'hidden', background: 'var(--bg-elevated)', position: 'relative' }}>
                        <ProductImg src={p.imageUrl} alt={p.name} />
                        <span className="badge badge-emerald" style={{ position: 'absolute', top: '0.5rem', left: '0.5rem', fontSize: '0.65rem', textTransform: 'capitalize' }}>{p.category}</span>
                      </div>
                      <div style={{ padding: '0.875rem' }}>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{p.brand}</div>
                        <div style={{ fontWeight: 700, fontSize: '0.95rem', margin: '0.2rem 0 0.5rem' }}>{p.name}</div>
                        <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', margin: '0 0 0.75rem', lineHeight: 1.5 }}>{p.shortDescription}</p>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span className="price-tag-sm">{p.minPrice > 0 ? formatINR(p.minPrice) : '—'}</span>
                          <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{p.storeCount} store{p.storeCount !== 1 ? 's' : ''}</span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Product Detail Overlay (inside browse tab) ─────────── */}
      {activeTab === 'browse' && selectedProduct && (
        <div style={{ padding: '1.5rem 0 3rem' }}>
          <div className="container">
            <button onClick={() => setSelectedProduct(null)} className="btn btn-ghost btn-sm" style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              ← Back to results
            </button>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '1.5rem', alignItems: 'start' }}>
              {/* Left */}
              <div>
                <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', height: 300, background: 'var(--bg-elevated)', marginBottom: '1.25rem' }}>
                  <ProductImg src={selectedProduct.imageUrl} alt={selectedProduct.name} />
                </div>
                <div style={{ marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', gap: '0.4rem', marginBottom: '0.4rem' }}>
                    <span className="badge badge-emerald" style={{ textTransform: 'capitalize' }}>{selectedProduct.category}</span>
                    <span className="badge badge-gray">{selectedProduct.brand}</span>
                  </div>
                  <h1 style={{ margin: '0 0 0.25rem', fontSize: '1.5rem' }}>{selectedProduct.name}</h1>
                  <p style={{ color: 'var(--text-muted)', margin: '0 0 0.5rem', fontSize: '0.8rem' }}>Model: {selectedProduct.model}</p>
                  <p style={{ color: 'var(--text-secondary)', margin: 0, fontSize: '0.9rem', lineHeight: 1.7 }}>{selectedProduct.shortDescription}</p>
                </div>

                {/* Specs */}
                <div className="card" style={{ marginBottom: '1.25rem' }}>
                  <div style={{ padding: '1rem 1.25rem', fontWeight: 700, borderBottom: '1px solid var(--border)' }}>Specifications</div>
                  <div style={{ padding: '0.875rem 1.25rem', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.4rem' }}>
                    {selectedProduct.specs.map((s, i) => (
                      <div key={i} style={{ padding: '0.4rem 0.6rem', background: 'var(--bg)', borderRadius: 6 }}>
                        <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{s.label}</div>
                        <div style={{ fontSize: '0.82rem', fontWeight: 500 }}>{s.value}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Store listings */}
                <h2 style={{ fontSize: '1rem', margin: '0 0 0.75rem' }}>Available at {productListings.length} store{productListings.length !== 1 ? 's' : ''}</h2>
                {productListings.map(l => (
                  <div key={l.id} className="card" onClick={() => { setSelectedListingId(l.id); setIncludeDelivery(false); setDiscountElig({}); }}
                    style={{ padding: '0.875rem 1.1rem', marginBottom: '0.5rem', cursor: 'pointer', border: selectedListingId === l.id ? '1px solid var(--emerald)' : '1px solid var(--border)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                        <div style={{ width: 32, height: 32, borderRadius: 8, background: `${l.store.accentColor}22`, border: `1.5px solid ${l.store.accentColor}44`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '0.7rem', color: l.store.accentColor, flexShrink: 0 }}>
                          {l.store.logoInitials}
                        </div>
                        <div>
                          <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>{l.store.name}</div>
                          <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{l.store.city} · {l.configuration}</div>
                        </div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                        <span className="price-tag-sm">{formatINR(l.price)}</span>
                        <span className="badge" style={{ background: `${stockColor(l.stockStatus)}22`, color: stockColor(l.stockStatus) }}>{stockLabel(l.stockStatus)}</span>
                        {l.isAvailable && (
                          <button className="btn btn-primary btn-sm" onClick={e => { e.stopPropagation(); startReserve(l.id); }}>Reserve</button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Right — TrueCost sticky */}
              <div style={{ position: 'sticky', top: 68 }}>
                {productListings.length > 0 && (
                  <div className="card-elevated" style={{ padding: '0.875rem', marginBottom: '0.75rem' }}>
                    <label className="form-label">Calculate cost for</label>
                    <select className="form-select" value={selectedListingId || ''} onChange={e => { setSelectedListingId(e.target.value); setIncludeDelivery(false); setDiscountElig({}); }}>
                      {productListings.map(l => <option key={l.id} value={l.id}>{l.store.name} — {formatINR(l.price)}</option>)}
                    </select>
                  </div>
                )}

                {trueCost && selListing && (
                  <div className="card-elevated" style={{ padding: '1.25rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '1rem' }}>
                      <Tag size={15} color="var(--emerald)" />
                      <span style={{ fontWeight: 700, fontSize: '0.9rem' }}>TrueCost™ Intelligence</span>
                      <span className="badge badge-amber" style={{ marginLeft: 'auto', fontSize: '0.6rem' }}>DEMO</span>
                    </div>
                    {/* Price rows */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.45rem 0', borderBottom: '1px solid var(--border)', fontSize: '0.875rem' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>Listed Price</span>
                      <span style={{ fontWeight: 700 }}>{formatINR(trueCost.listedPrice)}</span>
                    </div>
                    {trueCost.mandatoryFees.map((f, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.4rem 0', borderBottom: '1px solid var(--border)', fontSize: '0.82rem' }}>
                        <span style={{ color: 'var(--text-secondary)' }}>+ {f.label}</span>
                        <span style={{ color: '#fca5a5' }}>+{formatINR(f.amount)}</span>
                      </div>
                    ))}
                    {/* Delivery */}
                    <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', padding: '0.5rem 0', borderBottom: '1px solid var(--border)', cursor: 'pointer', fontSize: '0.82rem' }}>
                      <input type="checkbox" checked={includeDelivery} onChange={e => setIncludeDelivery(e.target.checked)} style={{ accentColor: 'var(--emerald)' }} />
                      <span style={{ color: 'var(--text-secondary)' }}>Include delivery</span>
                      <span style={{ marginLeft: 'auto', color: selListing.deliveryCharge === null ? 'var(--accent-amber)' : selListing.deliveryCharge === 0 ? 'var(--emerald)' : 'var(--text-primary)' }}>
                        {selListing.deliveryCharge === null ? 'Unknown' : selListing.deliveryCharge === 0 ? 'Free' : `+${formatINR(selListing.deliveryCharge)}`}
                      </span>
                    </label>
                    {/* Discounts */}
                    {selListing.discounts.map((d, i) => (
                      <label key={i} style={{ display: 'flex', gap: '0.4rem', padding: '0.4rem 0', cursor: 'pointer', fontSize: '0.78rem', borderBottom: '1px solid var(--border)' }}>
                        <input type="checkbox" checked={!!discountElig[d.label]} onChange={() => setDiscountElig(prev => ({ ...prev, [d.label]: !prev[d.label] }))} style={{ accentColor: 'var(--emerald)', marginTop: 2 }} />
                        <div>
                          <div style={{ color: discountElig[d.label] ? 'var(--emerald)' : 'var(--text-secondary)' }}>-{formatINR(d.amount)} · {d.label}</div>
                          <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>{d.eligibilityNote}</div>
                        </div>
                      </label>
                    ))}
                    {/* Missing info */}
                    {trueCost.missingInfo.length > 0 && (
                      <div style={{ padding: '0.5rem 0.6rem', background: 'rgba(245,158,11,0.08)', borderRadius: 6, margin: '0.5rem 0', fontSize: '0.72rem', color: '#fcd34d' }}>
                        {trueCost.missingInfo.map((m, i) => <div key={i}>⚠ {m}</div>)}
                      </div>
                    )}
                    {/* Total */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '0.875rem', borderTop: '2px solid var(--emerald)', marginTop: '0.5rem' }}>
                      <div>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>ESTIMATED TOTAL</div>
                        <div className="price-tag">{formatINR(trueCost.estimatedTotal)}</div>
                      </div>
                      {selListing.isAvailable && (
                        <button className="btn btn-primary btn-sm" onClick={() => startReserve(selListing.id)} id="truecost-reserve-btn">Reserve</button>
                      )}
                    </div>
                    <p style={{ fontSize: '0.68rem', color: 'var(--text-muted)', margin: '0.5rem 0 0' }}>⚠ DEMO — confirm prices with store.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
          <style>{`@media(max-width:900px){.container>[style*="gridTemplateColumns: 1fr 360px"]{grid-template-columns:1fr!important}}`}</style>
        </div>
      )}

      {/* ══════════════════ STORES TAB ═══════════════════════════ */}
      {activeTab === 'stores' && !selectedStore && (
        <div style={{ padding: '1.5rem 0 3rem' }}>
          <div className="container">
            <h1 style={{ margin: '0 0 1rem', fontSize: '1.5rem' }}>Demo Electronics Stores</h1>
            <input className="form-input" type="text" placeholder="Search stores…" value={storeQuery}
              onChange={e => setStoreQuery(e.target.value)} style={{ maxWidth: 380, marginBottom: '1.25rem' }} id="stores-portal-search" />
            <div className="grid-3">
              {filteredStores.map(s => (
                <button key={s.id} onClick={() => openStore(s)} style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', textAlign: 'left' }}>
                  <div className="card" style={{ padding: '1.25rem' }} id={`store-card-${s.id}`}>
                    <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', marginBottom: '0.75rem' }}>
                      <div style={{ width: 44, height: 44, borderRadius: 12, background: `${s.accentColor}22`, border: `1.5px solid ${s.accentColor}55`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '0.9rem', color: s.accentColor, flexShrink: 0 }}>
                        {s.logoInitials}
                      </div>
                      <div>
                        <div style={{ fontWeight: 700 }}>{s.name}</div>
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{s.city}, {s.state}</div>
                      </div>
                    </div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', gap: '0.35rem', marginBottom: '0.5rem' }}>
                      <MapPin size={12} style={{ flexShrink: 0, marginTop: 2 }} /> {s.address}
                    </div>
                    <span className="badge badge-emerald">{s.listingCount} products</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Store Detail Overlay ─────────────────────────────── */}
      {activeTab === 'stores' && selectedStore && (
        <div style={{ padding: '1.5rem 0 3rem' }}>
          <div className="container">
            <button onClick={() => setSelectedStore(null)} className="btn btn-ghost btn-sm" style={{ marginBottom: '1rem' }}>← All Stores</button>
            <div className="card-elevated" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start', flexWrap: 'wrap' }}>
                <div style={{ width: 60, height: 60, borderRadius: 14, background: `${selectedStore.accentColor}22`, border: `2px solid ${selectedStore.accentColor}55`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 900, fontSize: '1.2rem', color: selectedStore.accentColor, flexShrink: 0 }}>
                  {selectedStore.logoInitials}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', gap: '0.4rem', marginBottom: '0.3rem' }}><span className="badge badge-amber">DEMO STORE</span></div>
                  <h1 style={{ margin: '0 0 0.25rem', fontSize: '1.4rem' }}>{selectedStore.name}</h1>
                  <p style={{ color: 'var(--text-secondary)', margin: '0 0 0.875rem', fontSize: '0.875rem' }}>{selectedStore.description}</p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', fontSize: '0.83rem', color: 'var(--text-secondary)' }}>
                    <div style={{ display: 'flex', gap: '0.4rem' }}><MapPin size={14} style={{ color: 'var(--emerald)', flexShrink: 0 }} />{selectedStore.address}, {selectedStore.city} — {selectedStore.pincode}</div>
                    <div style={{ display: 'flex', gap: '0.4rem' }}><Phone size={14} style={{ color: 'var(--emerald)', flexShrink: 0 }} />{selectedStore.phone} <em style={{ color: 'var(--text-muted)' }}>(demo)</em></div>
                  </div>
                  <div style={{ marginTop: '0.875rem', display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <a href={mapsLink(selectedStore.coordinates.lat, selectedStore.coordinates.lng, selectedStore.name)} target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm">
                      <ExternalLink size={12} /> Open in Maps
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', gap: '1.25rem', alignItems: 'start' }}>
              <div className="card" style={{ padding: '1rem' }}>
                <div style={{ fontWeight: 700, fontSize: '0.85rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <Clock size={14} color="var(--emerald)" /> Hours <span style={{ fontSize: '0.65rem', color: 'var(--accent-amber)', fontWeight: 400 }}>(illustrative)</span>
                </div>
                {selectedStore.hours.map((h, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', padding: '0.3rem 0', borderBottom: i < selectedStore.hours.length - 1 ? '1px solid var(--border)' : 'none' }}>
                    <span style={{ color: 'var(--text-muted)' }}>{h.day}</span>
                    <span style={{ fontWeight: 500 }}>{h.open}–{h.close}</span>
                  </div>
                ))}
              </div>
              <div>
                <h2 style={{ margin: '0 0 0.75rem', fontSize: '1rem' }}>Products ({storeListings.length})</h2>
                {storeListings.map(l => (
                  <div key={l.id} className="card" style={{ padding: '0.875rem 1.1rem', marginBottom: '0.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
                      <div>
                        <button onClick={() => { openProduct(l.product); switchTab('browse'); }} style={{ fontWeight: 600, fontSize: '0.875rem', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--emerald)', padding: 0, fontFamily: 'inherit', textAlign: 'left' }}>
                          {l.product.name}
                        </button>
                        <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{l.configuration}</div>
                      </div>
                      <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                        <span className="price-tag-sm">{formatINR(l.price)}</span>
                        <span className="badge" style={{ background: `${stockColor(l.stockStatus)}22`, color: stockColor(l.stockStatus) }}>{stockLabel(l.stockStatus)}</span>
                        {l.isAvailable && <button className="btn btn-primary btn-sm" onClick={() => startReserve(l.id)} id={`store-reserve-${l.id}`}>Reserve</button>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <style>{`@media(max-width:700px){.container>[style*="240px 1fr"]{grid-template-columns:1fr!important}}`}</style>
        </div>
      )}

      {/* ══════════════════ RESERVATIONS TAB ═════════════════════ */}
      {activeTab === 'reservations' && (
        <div style={{ padding: '1.5rem 0 3rem' }}>
          <div className="container">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.75rem' }}>
              <div>
                <h1 style={{ margin: 0, fontSize: '1.5rem' }}>My Reservations</h1>
                <p style={{ margin: '0.2rem 0 0', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Stored in browser · DEMO</p>
              </div>
              <button className="btn btn-secondary btn-sm" onClick={loadReservations} style={{ display: 'flex', gap: '0.35rem' }}>
                <RefreshCw size={13} /> Refresh
              </button>
            </div>

            {/* Status filter */}
            <div style={{ display: 'flex', gap: '0.4rem', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
              {['all', 'pending', 'confirmed', 'cancelled', 'completed', 'rejected'].map(s => (
                <button key={s} onClick={() => setResFilter(s)}
                  style={{
                    padding: '0.25rem 0.75rem', borderRadius: 999, fontSize: '0.78rem', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                    background: resFilter === s ? 'rgba(16,185,129,0.2)' : 'var(--bg-elevated)',
                    color: resFilter === s ? 'var(--emerald)' : 'var(--text-secondary)',
                    outline: resFilter === s ? '1px solid var(--emerald)' : '1px solid var(--border)',
                  }} id={`res-filter-${s}`}>
                  {s.charAt(0).toUpperCase() + s.slice(1)}
                  {s !== 'all' && ` (${myReservations.filter(r => r.status === s).length})`}
                </button>
              ))}
            </div>

            {filteredReservations.length === 0 ? (
              <div className="empty-state">
                <div className="empty-state-icon">📋</div>
                <h3>{resFilter === 'all' ? 'No reservations yet' : `No ${resFilter} reservations`}</h3>
                {resFilter === 'all' && <button className="btn btn-primary" onClick={() => switchTab('browse')} style={{ marginTop: '1rem' }}>Browse Products</button>}
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {filteredReservations.map(r => (
                  <div key={r.id} className="card" style={{ padding: '1.1rem 1.25rem' }} id={`res-card-${r.id}`}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '0.75rem', marginBottom: '0.75rem' }}>
                      <div>
                        <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center', flexWrap: 'wrap', marginBottom: '0.3rem' }}>
                          <ReservationStatusBadge status={r.status} />
                          <span style={{ fontFamily: 'monospace', fontSize: '0.75rem', color: 'var(--text-muted)', background: 'var(--bg)', padding: '0.1rem 0.4rem', borderRadius: 4, border: '1px solid var(--border)' }}>{r.referenceNumber}</span>
                        </div>
                        <div style={{ fontWeight: 700 }}>{r.product?.name || r.productId}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{r.configuration}</div>
                      </div>
                      {(r.status === 'pending' || r.status === 'confirmed') && (
                        confirmCancel === r.id ? (
                          <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                            <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Cancel?</span>
                            <button className="btn btn-danger btn-sm" onClick={() => cancelReservation(r.id)}>Yes</button>
                            <button className="btn btn-ghost btn-sm" onClick={() => setConfirmCancel(null)}>No</button>
                          </div>
                        ) : (
                          <button className="btn btn-secondary btn-sm" onClick={() => setConfirmCancel(r.id)}
                            style={{ color: 'var(--accent-red)', borderColor: 'rgba(239,68,68,0.3)', display: 'flex', gap: '0.3rem' }}
                            id={`cancel-res-${r.id}`}>
                            <XCircle size={13} /> Cancel
                          </button>
                        )
                      )}
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '0.4rem', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                      {r.store && <div><div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Store</div>{r.store.name}, {r.store.city}</div>}
                      <div><div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Visit</div>{formatDate(r.visitDate)} at {r.visitTime}</div>
                      <div><div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Created</div>{formatDateTime(r.createdAt)}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <p style={{ textAlign: 'center', fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '1.5rem' }}>
              ⚠ Reservations are stored in your browser's local storage and are device-specific.
            </p>
          </div>
        </div>
      )}

      {/* ══════════════════ RESERVATION MODAL ═════════════════════ */}
      {reserveListingId && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', width: '100%', maxWidth: 520, maxHeight: '90vh', overflowY: 'auto' }}>
            {/* Modal header */}
            <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: '1rem' }}>
                  {resStep === 4 ? '✓ Reservation Submitted!' : `Reserve for Inspection — Step ${resStep}/3`}
                </div>
                {resProduct && <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{resProduct.name}</div>}
              </div>
              <button onClick={() => { setReserveListingId(null); setResConfirmedRef(null); }} className="btn btn-ghost btn-icon">✕</button>
            </div>

            <div style={{ padding: '1.5rem' }}>
              {/* Step 1: Contact */}
              {resStep === 1 && (
                <>
                  <div className="form-group">
                    <label className="form-label">Full Name *</label>
                    <input className="form-input" type="text" value={resForm.name} onChange={e => setResForm(f => ({ ...f, name: e.target.value }))} placeholder="Your full name" id="modal-res-name" />
                    {resErrors.name && <div className="form-error">{resErrors.name}</div>}
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone *</label>
                    <input className="form-input" type="tel" value={resForm.phone} onChange={e => setResForm(f => ({ ...f, phone: e.target.value }))} placeholder="+91 98000 00000" id="modal-res-phone" />
                    {resErrors.phone && <div className="form-error">{resErrors.phone}</div>}
                  </div>
                  <div className="form-group">
                    <label className="form-label">Email *</label>
                    <input className="form-input" type="email" value={resForm.email} onChange={e => setResForm(f => ({ ...f, email: e.target.value }))} placeholder="you@example.com" id="modal-res-email" />
                    {resErrors.email && <div className="form-error">{resErrors.email}</div>}
                  </div>
                  <div className="form-group">
                    <label className="form-label">Notes (optional)</label>
                    <textarea className="form-textarea" value={resForm.notes} onChange={e => setResForm(f => ({ ...f, notes: e.target.value }))} placeholder="Any special requests…" style={{ minHeight: 72 }} />
                  </div>
                  <div style={{ fontSize: '0.74rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>⚠ Demo: Do not enter real sensitive data. No payment collected.</div>
                  <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => validateResStep1() && setResStep(2) as any} id="modal-next-1">Next: Choose Visit Slot →</button>
                </>
              )}

              {/* Step 2: Date + Time */}
              {resStep === 2 && (
                <>
                  <div className="form-group">
                    <label className="form-label">Visit Date *</label>
                    <input className="form-input" type="date" min={getMinDate()} max={getMaxDate()} value={resForm.visitDate} onChange={e => setResForm(f => ({ ...f, visitDate: e.target.value }))} id="modal-res-date" />
                    {resErrors.visitDate && <div className="form-error">{resErrors.visitDate}</div>}
                  </div>
                  <div className="form-group">
                    <label className="form-label">Time Slot *</label>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.35rem' }}>
                      {TIME_SLOTS.map(t => (
                        <button key={t} onClick={() => setResForm(f => ({ ...f, visitTime: t }))}
                          style={{ padding: '0.35rem 0.2rem', fontSize: '0.78rem', borderRadius: 7, border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                            background: resForm.visitTime === t ? 'var(--emerald)' : 'var(--bg)',
                            color: resForm.visitTime === t ? '#fff' : 'var(--text-secondary)',
                            outline: resForm.visitTime === t ? 'none' : '1px solid var(--border)' }}
                          id={`modal-time-${t}`}>
                          {t}
                        </button>
                      ))}
                    </div>
                    {resErrors.visitTime && <div className="form-error" style={{ marginTop: '0.4rem' }}>{resErrors.visitTime}</div>}
                  </div>
                  <div style={{ display: 'flex', gap: '0.6rem', marginTop: '1rem' }}>
                    <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => setResStep(1)}>← Back</button>
                    <button className="btn btn-primary" style={{ flex: 2 }} onClick={() => { if (validateResStep2()) setResStep(3 as any); }} id="modal-next-2">Review →</button>
                  </div>
                </>
              )}

              {/* Step 3: Review */}
              {resStep === 3 && (
                <>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', marginBottom: '1.25rem' }}>
                    {[['Product', resProduct?.name || ''], ['Store', `${resStore?.name}, ${resStore?.city}`], ['Visit', `${formatDate(resForm.visitDate)} at ${resForm.visitTime}`], ['Name', resForm.name], ['Phone', resForm.phone], ['Email', resForm.email]].map(([l, v]) => (
                      <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.4rem 0', borderBottom: '1px solid var(--border)', fontSize: '0.875rem', gap: '0.75rem' }}>
                        <span style={{ color: 'var(--text-muted)', flexShrink: 0 }}>{l}</span>
                        <span style={{ fontWeight: 500, textAlign: 'right' }}>{v}</span>
                      </div>
                    ))}
                  </div>
                  <div style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 8, padding: '0.75rem', fontSize: '0.78rem', color: '#fcd34d', marginBottom: '1rem' }}>
                    <strong>No payment collected.</strong> This is a demo reservation only.
                  </div>
                  <div style={{ display: 'flex', gap: '0.6rem' }}>
                    <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => setResStep(2)}>← Edit</button>
                    <button className="btn btn-primary" style={{ flex: 2 }} onClick={submitReservation} disabled={resSubmitting} id="modal-confirm">
                      {resSubmitting ? 'Submitting…' : '✓ Confirm'}
                    </button>
                  </div>
                </>
              )}

              {/* Step 4: Confirmed */}
              {resStep === 4 && resConfirmedRef && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'rgba(16,185,129,0.15)', border: '2px solid var(--emerald)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem' }}>
                    <CheckCircle size={28} color="var(--emerald)" />
                  </div>
                  <h2 style={{ margin: '0 0 0.5rem' }}>Submitted!</h2>
                  <p style={{ color: 'var(--text-secondary)', margin: '0 0 1.25rem', fontSize: '0.875rem' }}>Your demo reservation is pending retailer confirmation.</p>
                  <div style={{ background: 'var(--bg)', borderRadius: 'var(--radius)', padding: '0.875rem 1.25rem', marginBottom: '1.25rem', border: '1px solid var(--border)' }}>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.35rem', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Reference Number</div>
                    <div style={{ fontFamily: 'Space Grotesk, monospace', fontSize: '1.3rem', fontWeight: 800, color: 'var(--emerald)', letterSpacing: '0.04em' }} id="confirmed-ref">{resConfirmedRef}</div>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'center', flexWrap: 'wrap' }}>
                    <button className="btn btn-primary" onClick={() => { setReserveListingId(null); setResConfirmedRef(null); switchTab('reservations'); }}>View My Reservations</button>
                    <button className="btn btn-secondary" onClick={() => { setReserveListingId(null); setResConfirmedRef(null); }}>Close</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
