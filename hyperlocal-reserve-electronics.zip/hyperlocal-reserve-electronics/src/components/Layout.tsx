import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Zap, Search, ShoppingBag, Store, BookOpen,
  Settings, Menu, X, ChevronDown, MapPin
} from 'lucide-react';
import type { DemoUser, DemoRole } from '../types';

const DEMO_ACCOUNTS: DemoUser[] = [
  { role: 'customer', name: 'Customer (Demo)' },
  { role: 'retailer', storeId: 'store-001', name: 'TechVerse Retailer' },
  { role: 'retailer', storeId: 'store-002', name: 'GadgetHub Retailer' },
  { role: 'admin', name: 'Admin (Demo)' },
];

const CURRENT_USER_KEY = 'hlr_current_user';

function getStoredUser(): DemoUser {
  try {
    const raw = localStorage.getItem(CURRENT_USER_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return DEMO_ACCOUNTS[0];
}

export function storeUser(user: DemoUser) {
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
}

export function useCurrentUser() {
  const [user, setUser] = useState<DemoUser>(getStoredUser());
  const switchUser = (u: DemoUser) => { storeUser(u); setUser(u); };
  return { user, switchUser };
}

interface NavbarProps {
  user: DemoUser;
  onSwitchUser: (u: DemoUser) => void;
}

export function Navbar({ user, onSwitchUser }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const location = useLocation();

  useEffect(() => { setMobileOpen(false); }, [location]);

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/products', label: 'Products' },
    { to: '/stores', label: 'Stores' },
    { to: '/reservations', label: 'My Reservations' },
    ...(user.role === 'retailer' ? [{ to: '/retailer', label: 'Retailer Dashboard' }] : []),
    ...(user.role === 'admin' ? [{ to: '/admin', label: 'Admin' }] : []),
  ];

  const roleColor: Record<DemoRole, string> = {
    customer: '#10b981',
    retailer: '#6366f1',
    admin: '#f59e0b',
  };

  return (
    <nav className="glass" style={{ position: 'sticky', top: 0, zIndex: 100, borderBottom: '1px solid var(--border)', borderRadius: 0 }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
        {/* Logo */}
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', textDecoration: 'none' }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'linear-gradient(135deg, #10b981, #059669)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            <Zap size={20} color="#fff" fill="#fff" />
          </div>
          <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 800, fontSize: '1.15rem' }}>
            Hyperlocal<span style={{ color: 'var(--emerald)' }}>Reserve</span>
          </span>
        </Link>

        {/* Desktop links */}
        <div style={{ display: 'flex', gap: '0.25rem', alignItems: 'center' }} className="desktop-nav">
          {navLinks.map(l => (
            <Link
              key={l.to}
              to={l.to}
              style={{
                padding: '0.4rem 0.875rem',
                borderRadius: 8,
                fontSize: '0.875rem',
                fontWeight: 500,
                color: location.pathname === l.to ? 'var(--emerald)' : 'var(--text-secondary)',
                background: location.pathname === l.to ? 'rgba(16,185,129,0.1)' : 'transparent',
                transition: 'all 0.15s',
              }}
            >
              {l.label}
            </Link>
          ))}
        </div>

        {/* Right side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <Link to="/products" className="btn btn-ghost btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <Search size={16} />
          </Link>

          {/* Account switcher */}
          <div style={{ position: 'relative' }}>
            <button
              className="btn btn-secondary btn-sm"
              onClick={() => setAccountOpen(o => !o)}
              style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}
            >
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: roleColor[user.role], flexShrink: 0 }} />
              <span style={{ maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.name}</span>
              <ChevronDown size={14} />
            </button>
            {accountOpen && (
              <div style={{
                position: 'absolute', right: 0, top: '110%',
                background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                borderRadius: 'var(--radius)', padding: '0.5rem', minWidth: 200,
                zIndex: 200, boxShadow: 'var(--shadow)'
              }}>
                <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', padding: '0.25rem 0.5rem 0.5rem', margin: 0, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  Demo Account
                </p>
                {DEMO_ACCOUNTS.map((acc, i) => (
                  <button
                    key={i}
                    onClick={() => { onSwitchUser(acc); setAccountOpen(false); }}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '0.5rem',
                      width: '100%', padding: '0.5rem 0.75rem', borderRadius: 8,
                      background: user.name === acc.name ? 'rgba(16,185,129,0.1)' : 'transparent',
                      border: 'none', cursor: 'pointer', color: 'var(--text-primary)',
                      fontSize: '0.875rem', fontFamily: 'inherit', textAlign: 'left'
                    }}
                  >
                    <span style={{ width: 8, height: 8, borderRadius: '50%', background: roleColor[acc.role], flexShrink: 0 }} />
                    {acc.name}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button className="btn btn-ghost btn-icon" onClick={() => setMobileOpen(o => !o)} style={{ display: 'none' }} id="mobile-menu-btn">
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div style={{ borderTop: '1px solid var(--border)', padding: '1rem', background: 'var(--bg-card)' }}>
          {navLinks.map(l => (
            <Link
              key={l.to}
              to={l.to}
              style={{
                display: 'block', padding: '0.75rem 1rem', borderRadius: 8,
                color: location.pathname === l.to ? 'var(--emerald)' : 'var(--text-primary)',
                fontSize: '0.9375rem', fontWeight: 500,
                background: location.pathname === l.to ? 'rgba(16,185,129,0.1)' : 'transparent',
              }}
            >
              {l.label}
            </Link>
          ))}
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          #mobile-menu-btn { display: flex !important; }
        }
      `}</style>
    </nav>
  );
}

export function Footer() {
  return (
    <footer style={{ background: 'var(--bg-card)', borderTop: '1px solid var(--border)', marginTop: 'auto', padding: '2rem 0' }}>
      <div className="container">
        <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.75rem' }}>
              <div style={{ width: 28, height: 28, borderRadius: 8, background: 'linear-gradient(135deg, #10b981, #059669)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Zap size={15} color="#fff" fill="#fff" />
              </div>
              <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 700, fontSize: '0.95rem' }}>
                Hyperlocal<span style={{ color: 'var(--emerald)' }}>Reserve</span>
              </span>
            </div>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', margin: 0 }}>
              Find it nearby. Compare it smartly. Inspect before you buy.
            </p>
            <p style={{ fontSize: '0.75rem', color: '#f59e0b', marginTop: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              ⚠ DEMO MODE — All data is fictional
            </p>
          </div>
          <div>
            <h4 style={{ fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>Discover</h4>
            {[['/', 'Home'], ['/products', 'Browse Products'], ['/stores', 'Find Stores'], ['/products?category=laptops', 'Laptops']].map(([href, label]) => (
              <Link key={href} to={href} style={{ display: 'block', fontSize: '0.8375rem', color: 'var(--text-muted)', marginBottom: '0.4rem' }}>{label}</Link>
            ))}
          </div>
          <div>
            <h4 style={{ fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>Account</h4>
            {[['/reservations', 'My Reservations'], ['/retailer', 'Retailer Portal'], ['/admin', 'Admin Panel']].map(([href, label]) => (
              <Link key={href} to={href} style={{ display: 'block', fontSize: '0.8375rem', color: 'var(--text-muted)', marginBottom: '0.4rem' }}>{label}</Link>
            ))}
          </div>
          <div>
            <h4 style={{ fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>Notice</h4>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', lineHeight: '1.6' }}>
              All prices, stores, contact details, and stock information are fictional demo data. No real transactions occur.
            </p>
          </div>
        </div>
        <div className="divider" style={{ margin: '1rem 0' }} />
        <p style={{ textAlign: 'center', fontSize: '0.78rem', color: 'var(--text-muted)', margin: 0 }}>
          © 2026 Hyperlocal Reserve — Demo Application. No real purchases or reservations are processed.
        </p>
      </div>
    </footer>
  );
}
