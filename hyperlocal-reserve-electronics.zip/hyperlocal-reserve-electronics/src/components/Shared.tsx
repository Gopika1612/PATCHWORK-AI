import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Package, TrendingDown, ExternalLink } from 'lucide-react';
import type { Product, StoreListing } from '../types';
import { formatINR, stockLabel, stockColor } from '../utils/helpers';

// ── Product Card ──────────────────────────────────────────────────
interface ProductCardProps {
  product: Product;
  minPrice?: number;
  storeCount?: number;
  distanceKm?: number;
}

export function ProductCard({ product, minPrice, storeCount, distanceKm }: ProductCardProps) {
  const [imgError, setImgError] = useState(false);

  return (
    <Link to={`/products/${product.id}`} style={{ textDecoration: 'none' }}>
      <div className="card fade-in-up" style={{ cursor: 'pointer', height: '100%', display: 'flex', flexDirection: 'column' }}>
        {/* Image */}
        <div style={{ aspectRatio: '16/9', overflow: 'hidden', background: 'var(--bg-elevated)', position: 'relative' }}>
          {!imgError ? (
            <img
              src={product.imageUrl}
              alt={product.name}
              onError={() => setImgError(true)}
              style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.3s' }}
              className="product-img"
            />
          ) : (
            <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', color: 'var(--text-muted)' }}>
              <Package size={32} style={{ marginBottom: '0.5rem', opacity: 0.5 }} />
              <span style={{ fontSize: '0.75rem' }}>{product.brand}</span>
            </div>
          )}
          <div style={{ position: 'absolute', top: '0.5rem', left: '0.5rem' }}>
            <span className="badge badge-emerald" style={{ fontSize: '0.7rem', textTransform: 'capitalize' }}>
              {product.category}
            </span>
          </div>
        </div>

        {/* Content */}
        <div style={{ padding: '1rem', flex: 1, display: 'flex', flexDirection: 'column' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.25rem', fontWeight: 500 }}>
            {product.brand} · {product.model}
          </div>
          <h3 style={{ margin: '0 0 0.5rem', fontSize: '1rem', fontWeight: 700, lineHeight: 1.3 }}>
            {product.name}
          </h3>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', margin: '0 0 1rem', flex: 1, lineHeight: 1.5 }}>
            {product.shortDescription}
          </p>

          {/* Meta row */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
            <div>
              {minPrice !== undefined && (
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Starting from</div>
              )}
              <div className="price-tag-sm">
                {minPrice !== undefined ? formatINR(minPrice) : 'See stores'}
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '0.2rem' }}>
              {storeCount !== undefined && (
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                  <Package size={12} /> {storeCount} store{storeCount !== 1 ? 's' : ''}
                </div>
              )}
              {distanceKm !== undefined && (
                <div style={{ fontSize: '0.75rem', color: 'var(--emerald)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                  <MapPin size={12} /> {distanceKm.toFixed(1)} km
                </div>
              )}
            </div>
          </div>
        </div>
        <style>{`.product-img:hover { transform: scale(1.05); }`}</style>
      </div>
    </Link>
  );
}

// ── Store Card ────────────────────────────────────────────────────
interface StoreCardProps {
  store: import('../types').Store;
  listingCount?: number;
  distanceKm?: number;
}

export function StoreCard({ store, listingCount, distanceKm }: StoreCardProps) {
  return (
    <Link to={`/stores/${store.id}`} style={{ textDecoration: 'none' }}>
      <div className="card" style={{ padding: '1.25rem', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
          <div style={{
            width: 48, height: 48, borderRadius: 12, flexShrink: 0,
            background: `${store.accentColor}22`,
            border: `1.5px solid ${store.accentColor}66`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 800, fontSize: '1rem', color: store.accentColor,
            fontFamily: 'Space Grotesk, sans-serif'
          }}>
            {store.logoInitials}
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: '0.975rem' }}>{store.name}</div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{store.city}, {store.state}</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
          <MapPin size={13} /> {store.address}
        </div>
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
          {listingCount !== undefined && (
            <span className="badge badge-emerald">{listingCount} products</span>
          )}
          {distanceKm !== undefined && (
            <span className="badge badge-indigo"><MapPin size={10} /> {distanceKm.toFixed(1)} km away</span>
          )}
        </div>
      </div>
    </Link>
  );
}

// ── Listing Row (price comparison) ───────────────────────────────
interface ListingRowProps {
  listing: StoreListing;
  store: import('../types').Store;
  isCheapest?: boolean;
  distanceKm?: number;
}

export function ListingRow({ listing, store, isCheapest, distanceKm }: ListingRowProps) {
  const totalFees = listing.mandatoryFees.reduce((s, f) => s + f.amount, 0);
  const estimatedMin = listing.price + totalFees;

  return (
    <tr>
      <td>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{
            width: 36, height: 36, borderRadius: 8,
            background: `${store.accentColor}22`,
            border: `1.5px solid ${store.accentColor}66`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 800, fontSize: '0.8rem', color: store.accentColor,
            fontFamily: 'Space Grotesk, sans-serif', flexShrink: 0
          }}>
            {store.logoInitials}
          </div>
          <div>
            <Link to={`/stores/${store.id}`} style={{ fontWeight: 600, fontSize: '0.9rem', color: 'var(--text-primary)' }}>
              {store.name}
            </Link>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{store.city}</div>
          </div>
        </div>
      </td>
      <td>
        <div className="price-tag-sm">{formatINR(listing.price)}</div>
        {isCheapest && <span className="badge badge-emerald" style={{ marginTop: '0.25rem', display: 'inline-flex' }}><TrendingDown size={10} /> Lowest price</span>}
      </td>
      <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
        {listing.mandatoryFees.map((f, i) => (
          <div key={i}>{f.label}: {formatINR(f.amount)}</div>
        ))}
        {listing.mandatoryFees.length === 0 && <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>None</span>}
      </td>
      <td>
        <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
          {listing.discounts.length === 0
            ? <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>None listed</span>
            : listing.discounts.map((d, i) => (
              <div key={i} title={d.eligibilityNote}>
                -{formatINR(d.amount)} <span style={{ fontSize: '0.7rem', color: 'var(--accent-amber)' }}>(cond.)</span>
              </div>
            ))
          }
        </div>
      </td>
      <td style={{ fontSize: '0.8rem', color: listing.deliveryCharge === null ? 'var(--accent-amber)' : listing.deliveryCharge === 0 ? 'var(--emerald)' : 'var(--text-secondary)' }}>
        {listing.deliveryCharge === null ? 'Not provided' : listing.deliveryCharge === 0 ? 'Free' : formatINR(listing.deliveryCharge)}
      </td>
      <td>
        <div style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--emerald)' }}>
          {formatINR(estimatedMin)}
        </div>
        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>w/ mandatory fees</div>
      </td>
      <td>
        <span className="badge" style={{ background: `${stockColor(listing.stockStatus)}22`, color: stockColor(listing.stockStatus) }}>
          {stockLabel(listing.stockStatus)}
        </span>
      </td>
      <td>
        {distanceKm !== undefined
          ? <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}><MapPin size={12} />{distanceKm.toFixed(1)} km</span>
          : <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>—</span>
        }
      </td>
      <td>
        {listing.isAvailable
          ? <Link to={`/reserve/${listing.id}`} className="btn btn-primary btn-sm">Reserve</Link>
          : <span className="badge badge-red">Unavailable</span>
        }
      </td>
    </tr>
  );
}

// ── TrueCost Widget ───────────────────────────────────────────────
import { calculateTrueCost } from '../utils/trueCost';
import { formatDateTime } from '../utils/helpers';
import { Info, Truck, Tag } from 'lucide-react';

interface TrueCostWidgetProps {
  listing: StoreListing;
}

export function TrueCostWidget({ listing }: TrueCostWidgetProps) {
  const [includeDelivery, setIncludeDelivery] = useState(false);
  const [discountEligibility, setDiscountEligibility] = useState<Record<string, boolean>>({});

  const result = calculateTrueCost(listing, { includeDelivery, discountEligibility });

  const toggleDiscount = (label: string) => {
    setDiscountEligibility(prev => ({ ...prev, [label]: !prev[label] }));
  };

  return (
    <div className="card-elevated" style={{ padding: '1.5rem' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
        <div style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(16,185,129,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Tag size={16} color="var(--emerald)" />
        </div>
        <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 700 }}>TrueCost™ Intelligence</h3>
        <span className="badge badge-amber" style={{ marginLeft: 'auto', fontSize: '0.65rem' }}>DEMO</span>
      </div>

      {/* Listed price */}
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.6rem 0', borderBottom: '1px solid var(--border)' }}>
        <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>Listed Price</span>
        <span style={{ fontWeight: 700 }}>{formatINR(result.listedPrice)}</span>
      </div>

      {/* Mandatory fees */}
      {result.mandatoryFees.map((f, i) => (
        <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.5rem 0', borderBottom: '1px solid var(--border)', fontSize: '0.875rem' }}>
          <span style={{ color: 'var(--text-secondary)' }}>+ {f.label}</span>
          <span style={{ color: '#fca5a5' }}>+{formatINR(f.amount)}</span>
        </div>
      ))}

      {/* Delivery option */}
      <div style={{ padding: '0.75rem 0', borderBottom: '1px solid var(--border)' }}>
        <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={includeDelivery}
            onChange={e => setIncludeDelivery(e.target.checked)}
            style={{ accentColor: 'var(--emerald)' }}
          />
          <Truck size={14} color="var(--text-secondary)" />
          <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>Include delivery charge</span>
          <span style={{ marginLeft: 'auto', fontSize: '0.875rem', color: listing.deliveryCharge === null ? 'var(--accent-amber)' : listing.deliveryCharge === 0 ? 'var(--emerald)' : 'var(--text-primary)' }}>
            {listing.deliveryCharge === null ? 'Not provided' : listing.deliveryCharge === 0 ? 'Free' : `+${formatINR(listing.deliveryCharge)}`}
          </span>
        </label>
      </div>

      {/* Discounts */}
      {listing.discounts.length > 0 && (
        <div style={{ padding: '0.5rem 0', borderBottom: '1px solid var(--border)' }}>
          <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '0.5rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Potential Discounts</div>
          {listing.discounts.map((d, i) => (
            <label key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', cursor: 'pointer', marginBottom: '0.5rem' }}>
              <input
                type="checkbox"
                checked={!!discountEligibility[d.label]}
                onChange={() => toggleDiscount(d.label)}
                style={{ accentColor: 'var(--emerald)', marginTop: '0.15rem' }}
              />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.85rem', color: discountEligibility[d.label] ? 'var(--emerald)' : 'var(--text-secondary)' }}>
                  -{formatINR(d.amount)} — {d.label}
                </div>
                <div style={{ fontSize: '0.74rem', color: 'var(--text-muted)' }}>{d.eligibilityNote}</div>
              </div>
            </label>
          ))}
        </div>
      )}

      {/* Missing info warnings */}
      {result.missingInfo.length > 0 && (
        <div style={{ padding: '0.75rem', background: 'rgba(245,158,11,0.08)', borderRadius: 8, margin: '0.75rem 0', border: '1px solid rgba(245,158,11,0.2)' }}>
          {result.missingInfo.map((m, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.4rem', fontSize: '0.78rem', color: '#fcd34d', marginBottom: i < result.missingInfo.length - 1 ? '0.3rem' : 0 }}>
              <Info size={12} style={{ marginTop: 2, flexShrink: 0 }} /> {m}
            </div>
          ))}
        </div>
      )}

      {/* Total */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '1rem', marginTop: '0.5rem', borderTop: '2px solid var(--emerald)' }}>
        <div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Estimated Total</div>
          <div className="price-tag">{formatINR(result.estimatedTotal)}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Updated</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{formatDateTime(result.lastUpdated)}</div>
        </div>
      </div>
      <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', margin: '0.75rem 0 0', fontStyle: 'italic' }}>
        ⚠ DEMO DATA: Prices are illustrative. Confirm with the store before purchasing.
      </p>
    </div>
  );
}

// ── Status badge ──────────────────────────────────────────────────
export function ReservationStatusBadge({ status }: { status: string }) {
  const colorMap: Record<string, string> = {
    pending: 'badge-amber',
    confirmed: 'badge-emerald',
    rejected: 'badge-red',
    cancelled: 'badge-gray',
    completed: 'badge-indigo',
  };
  const label: Record<string, string> = {
    pending: 'Pending', confirmed: 'Confirmed', rejected: 'Rejected', cancelled: 'Cancelled', completed: 'Completed',
  };
  return <span className={`badge ${colorMap[status] || 'badge-gray'}`}>{label[status] || status}</span>;
}

// ── Toast notification ────────────────────────────────────────────
interface ToastProps {
  message: string;
  type?: 'success' | 'error' | 'info';
  onClose: () => void;
}

export function Toast({ message, type = 'success', onClose }: ToastProps) {
  useEffect(() => {
    const t = setTimeout(onClose, 3500);
    return () => clearTimeout(t);
  }, [onClose]);

  const colors = { success: 'var(--emerald)', error: 'var(--accent-red)', info: 'var(--accent-indigo)' };

  return (
    <div className="toast" style={{ borderLeft: `3px solid ${colors[type]}` }}>
      <span style={{ color: colors[type], fontSize: '1rem' }}>{type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
      <span style={{ fontSize: '0.875rem', flex: 1 }}>{message}</span>
      <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '0.1rem' }}>✕</button>
    </div>
  );
}

// Add useEffect import
import { useEffect } from 'react';
