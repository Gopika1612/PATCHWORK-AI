import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Navbar, Footer, useCurrentUser } from './components/Layout';
import CustomerPortal from './components/CustomerPortal';
import HomePage from './pages/HomePage';
import ProductsPage from './pages/ProductsPage';
import ProductDetailPage from './pages/ProductDetailPage';
import ComparisonPage from './pages/ComparisonPage';
import StoresPage from './pages/StoresPage';
import StoreDetailPage from './pages/StoreDetailPage';
import ReservationPage from './pages/ReservationPage';
import MyReservationsPage from './pages/MyReservationsPage';
import RetailerDashboard from './pages/RetailerDashboard';
import AdminPage from './pages/AdminPage';

function App() {
  const { user, switchUser } = useCurrentUser();

  return (
    <BrowserRouter>
      {/* Demo Mode Banner */}
      <div className="demo-banner">
        ⚡ DEMO MODE — All prices, stores, stock information, and contact details are fictional and illustrative. No real transactions occur.
      </div>

      <Navbar user={user} onSwitchUser={switchUser} />

      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          {/* Single-URL Customer Portal */}
          <Route path="/customer" element={<CustomerPortal />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/products/:id" element={<ProductDetailPage />} />
          <Route path="/compare/:productId" element={<ComparisonPage />} />
          <Route path="/stores" element={<StoresPage />} />
          <Route path="/stores/:id" element={<StoreDetailPage />} />
          <Route path="/reserve/:listingId" element={<ReservationPage />} />
          <Route path="/reservations" element={<MyReservationsPage />} />
          <Route path="/retailer" element={<RetailerDashboard user={user} />} />
          <Route path="/admin" element={<AdminPage user={user} />} />
          <Route path="*" element={
            <div className="page-wrapper">
              <div className="container">
                <div className="empty-state">
                  <div className="empty-state-icon">🔌</div>
                  <h3>404 — Page not found</h3>
                  <p>This page doesn't exist in the demo.</p>
                  <a href="/" className="btn btn-primary" style={{ marginTop: '1rem' }}>Go Home</a>
                </div>
              </div>
            </div>
          } />
        </Routes>
      </main>

      <Footer />
    </BrowserRouter>
  );
}

export default App;
