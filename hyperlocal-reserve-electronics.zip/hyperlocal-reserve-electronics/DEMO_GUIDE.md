# Hyperlocal Reserve — Demo Guide 🔋

> Walk through the complete feature set in ~15 minutes.

---

## 🔑 Quick Start

```bash
cd hyperlocal-reserve-electronics
npm install
npm run dev
# Open http://localhost:5173
```

---

## 🗺 Complete Demo Walkthrough

### Step 1 — Home Page
- Visit **http://localhost:5173/**
- You'll see the **Demo Mode banner** at the very top — confirming no real data is shown.
- The hero displays the tagline and a **search bar**. Type `laptop` and press Search.
- Scroll to see **Category Shortcuts**, **Featured Products**, **How It Works**, and **Demo Stores**.

### Step 2 — Product Discovery
- Visit **http://localhost:5173/products**
- All 8 demo products are shown with starting prices and store counts.
- **Search**: Type `MacBook` or `gaming` — results filter in real time.
- **Category filter**: Click "Laptops" or "Gaming" pills.
- **Sort**: Change the sort dropdown to "Price: Low to High".
- **Advanced filters**: Click the Filters button → filter by brand "PhoenixGear" or price range.
- **Geolocation**: Click "Use location" — browser will ask permission. If granted, stores are sorted by distance.

### Step 3 — Product Detail
- Click **"UltraBook Pro 16"**
- See: brand, model, specs table, multiple store listings.
- **Select a store** from the dropdown on the right → the **TrueCost™ widget** updates.
- **Check "Include delivery charge"** → total updates instantly.
- **Tick a discount checkbox** → total decreases (eligibility is your responsibility to confirm).
- Missing delivery info is shown as "Not provided" — never silently zero.
- Click **"Full Comparison"** → see the price comparison table.

### Step 4 — Price Comparison
- Visit **http://localhost:5173/compare/prod-001**
- See all 3 stores carrying UltraBook Pro 16 in one table.
- Columns: listed price, mandatory fees, conditional discounts, delivery, estimated total, stock, distance.
- The lowest-price store gets a "Lowest price" badge — but only when all fees are known.
- Note the `*conditional*` label on discounts — eligibility must be confirmed with the store.

### Step 5 — Store Details
- Visit **http://localhost:5173/stores**
- 5 demo stores listed. Click **TechVerse Electronics**.
- See: address, phone (marked demo), opening hours (marked illustrative), products in stock.
- Click **"Open in Maps"** → opens Google Maps with the demo address.
- Click any product → Reserve button available for in-stock items.

### Step 6 — Making a Reservation
- From any product listing, click **Reserve**.
- **Step 1 (Contact Details)**:
  - Name: `Test User`
  - Phone: `+91 98765 43210`
  - Email: `test@demo.com`
  - Click **Next: Choose Visit Slot →**
- **Step 2 (Visit Slot)**:
  - Select a date (tomorrow → 30 days ahead)
  - Click a time slot e.g. `11:00`
  - Click **Review Reservation →**
- **Step 3 (Review)**:
  - Confirm all details
  - Click **✓ Confirm Reservation**
- You'll see a **confirmation screen with a reference number** like `HLR-20261011-7231`.

> Note: No payment is ever requested. The demo note explains this is simulated.

### Step 7 — My Reservations
- Visit **http://localhost:5173/reservations**
- Your just-created reservation appears with status **Pending**.
- The 3 pre-loaded sample reservations are also shown (different statuses).
- **Filter** by status: click Pending, Confirmed, Cancelled tabs.
- **Cancel a pending reservation**: Click Cancel → confirm → status changes to Cancelled immediately.
- Refresh the page → reservations persist (localStorage).

### Step 8 — Retailer Dashboard
- In the **navbar**, click the account button (shows coloured dot + name).
- Switch to **"TechVerse Retailer"**.
- Navigate to **http://localhost:5173/retailer**.
- **Inventory tab**:
  - See all listings for TechVerse store.
  - Click the ✏ edit button on any listing → change price, stock, status → click Save.
  - Click **+ Add Listing** → select a product, set price, stock → Save.
  - Click 🗑 delete → confirm.
- **Reservations tab**:
  - See the reservation made in Step 6 (Pending).
  - Click **✓ Confirm** → status changes to Confirmed.
  - Customer would see this update on their My Reservations page.

### Step 9 — Admin Panel
- Switch account to **"Admin (Demo)"**.
- Visit **http://localhost:5173/admin**.
- **Overview tab**: Stats cards show total products, stores, listings, reservations + breakdown by status.
- **Reservations tab**: Full table of all reservations across all stores.
- **Listings tab**: Full table of all product listings.
- **Reset button**: Click "Restore Original Data" → you'll be asked to confirm → all changes are wiped and seed data is restored.

---

## 🧪 Running Unit Tests

```bash
npx tsx src/tests/trueCost.test.ts
```

Expected output: **22 passed, 0 failed** covering:
- Basic cost calculation
- With/without delivery
- With/without discounts
- Double-discount prevention
- Unknown delivery → "Not provided" (never silently zero)
- Negative price validation
- Total cannot go below zero
- EMI calculator (with interest, zero interest, negative principal)

---

## 🎭 Demo Accounts Summary

| Account | Role | Access |
|---------|------|--------|
| Customer (Demo) | customer | Browse, search, reserve, view my reservations |
| TechVerse Retailer | retailer | + Retailer dashboard for store-001 |
| GadgetHub Retailer | retailer | + Retailer dashboard for store-002 |
| Admin (Demo) | admin | + Admin panel, data reset |

Switch accounts via the **navbar account switcher** (top-right, shows a coloured dot).

---

## 📦 Sample Data Overview

| Entity | Count |
|--------|-------|
| Products | 8 (laptops, smartphones, tablets, monitors, accessories, gaming) |
| Stores | 5 (Bengaluru, Chennai, Mumbai, Noida, Hyderabad) |
| Listings | 20 (multiple stores per product for comparison) |
| Sample Reservations | 3 (confirmed, pending, cancelled) |

---

## ⚠ Known Limitations (Demo Only)

- **localStorage only** — not secure, not multi-user, no cross-device sync.
- **No stock locking** — two users could reserve the same unit.
- **No real email/SMS** — no actual confirmation messages sent.
- **Images** require internet access (Unsplash CDN). Fallback placeholder shown when offline.
- **Browser-specific** — clearing browser data resets reservations (use Admin panel to restore seed data instead).
